import React, { useEffect, useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useLocation,
} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import '@fortawesome/fontawesome-free/css/all.min.css';
import WelcomePage from "./components/home.component";
import Signin from "./components/login.component";
import Dashboard from "./components/dashboard.component";
import ForgotPassword from "./components/ForgotPassword.component";
import AuthService from "./components/authService";
import UpgradeYourPlan from "./components/UpgradePlan";
import Settings from "./components/SettingPage";
import ResetCode from "./components/ResetCode";
import ChatComponent from "./components/chatComponent";
import Topbar from "./components/Topbar";
import { ThemeContextProvider } from "./components/ThemeContext"; // ThemeContext
import Signup from "./components/signup.component";
import SetPassword from "./components/setGooglepassword.jsx";
import RazorpayPayment from "./components/PaymentPage2.jsx";

// PrivateRoute Component
const PrivateRoute = ({ element }) => {
  const isAuthenticated = AuthService.isAuthenticated; // Update dynamically if needed
  return isAuthenticated ? element : <Navigate to="/sign-in" replace />;
};

// Main Application Component
function MainApp() {
  const [isClicked, setIsClicked] = useState(false); // State for DashNavbar
  const [selectedHistory, setSelectedHistory] = useState(null); // State for selected history
  const location = useLocation(); // Current path

  // Pages where navbar is hidden
  const hideNavbar = [
    "/",
    "/sign-in",
    "/sign-up",
    "/reset_password",
    "/forgotPass",
    "/setting",
    "/chatpage",
    "/upgradeyourplan",
    "/setGooglepassword",
    "/payment2",
    
  ].includes(location.pathname);
  

  return (
    <div className="App">
      {/* {!hideNavbar && <Topbar isClicked={isClicked} setIsClicked={setIsClicked} />} */}
      <Routes>
      <Route path="/" element={<WelcomePage />} />
        <Route path="/sign-in" element={<Signin />} />
        <Route path="/sign-up" element={<Signup />} />
        <Route path="/forgotPass" element={<ForgotPassword />} />
        <Route path="/reset_password"   element={<ResetCode />} />        
        <Route path="/setGooglepassword"   element={<SetPassword/>} />        

        <Route
          path="/dashboard"
          element={
            // <PrivateRoute
            //   element={
                <Dashboard
                  selectedHistory={selectedHistory}
                  setSelectedHistory={setSelectedHistory}
              //   />
              // }
            />
          }
        />
        <Route
          path="/upgradeyourplan"
          element={<PrivateRoute element={<UpgradeYourPlan />} />}
        />
       
         <Route
          path="/payment2"
          element={<PrivateRoute element={<RazorpayPayment />} />}
        />
        <Route
          path="/setting"
          element={<PrivateRoute element={<Settings />} />}
        />
       
        <Route
          path="/chatpage"
          element={<PrivateRoute element={<ChatComponent />} />}
        />
        
      </Routes>
    </div>
  );
}

// Main App Wrapper
function App() {
  useEffect(() => {
    AuthService.initializeAuth(); // Initialize authentication state
  }, []);

  // Reset session logic (to be implemented if backend interaction is required)
  const resetSessionTimer = () => {
    console.log("Session reset triggered");
    // Add backend or local session reset logic here
  };

  return (
    <ThemeContextProvider>
      <div
        onMouseMove={resetSessionTimer}
        onClick={resetSessionTimer}
        onKeyPress={resetSessionTimer}
      >
        <Router>
          <MainApp />
        </Router>
      </div>
    </ThemeContextProvider>
  );
}

export default App;
