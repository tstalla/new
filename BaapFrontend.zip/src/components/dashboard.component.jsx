import React, { useState, useEffect,useRef } from 'react';
import { Box, Button, TextField,Grid, IconButton } from '@mui/material';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import { ImImage } from 'react-icons/im';
import { FaMicrophone } from 'react-icons/fa6';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import { IoSend } from 'react-icons/io5';
import { useTheme } from "@mui/material/styles";


const App = ({setSelectedHistory ,selectedHistory} ) => {
  const [messages1, setMessages1] = useState([]);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(null);
  const [userId, setuserId] = useState(null);
  const [isListening, setIsListening] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [isBotProcessing, setBotProcessing] = useState(false);
  const [inputCount, setInputCount] = useState(0);
  const [selectedImage, setSelectedImage] = useState(null);
  const [, setIsLoading] = useState(false);
  const [isScrolledToBottom, setIsScrolledToBottom] = useState(true); // Track scroll position
  const messagesEndRef = useRef(null);
  const chatContainerRef = useRef(null);
  const historyRef = useRef(null); // Ref to scroll to the top of the container
  const theme = useTheme(); // Access the theme

  useEffect(() => {
    const storedUserId = localStorage.getItem('user_id');
    const storedInputCount = localStorage.getItem('inputCount');

    if (storedUserId) {
      setuserId(storedUserId);
    }
    if (storedInputCount) {
      setInputCount(Number(storedInputCount));
    }
    
  }, []);
  

  // Initialize sidebar state based on window width
  useEffect(() => {
    const updateSidebarState = () => {
      if (window.innerWidth >= 700) {
        setIsSidebarCollapsed(false); // Collapse sidebar on larger screens by default
      } else {
        setIsSidebarCollapsed(true); // Keep it collapsed on smaller screens
      }
    };

    // Set initial state
    updateSidebarState();

    // Add resize listener to update sidebar state
    window.addEventListener('resize', updateSidebarState);

    // Clean up listener on unmount
    return () => {
      window.removeEventListener('resize', updateSidebarState);
    };
  }, []);

  const sendMessageToDjango = async () => {
    if (inputCount >= 5) {
      alert("You have completed today's free trial hits. Get Plus to hit more!");
      return;
    }

    const updatedCount = inputCount + 1;
    setInputCount(updatedCount);
    localStorage.setItem('inputCount', updatedCount);

    if (isBotProcessing) {
      return;
    }

    setBotProcessing(true);
    const formData = new FormData();
    formData.append('user_input', userInput);
    formData.append('user_id', userId);
    if (selectedImage) {
      formData.append('img', selectedImage);
    }

    try {
      setIsLoading(true);
      const response1 = await fetch('http://127.0.0.1:8000/api1_chat/', {
        method: 'POST',
        body: formData,
      });

      if (!response1.ok) {
        throw new Error('Failed to fetch API 1');
      }

      const responseData1 = await response1.json();
      console.log("API_Response1:",responseData1);
      setMessages1((prevMessages) => [
        ...prevMessages,
        { type: 'user', text: userInput },
        { type: 'bot', text: responseData1.bot_response || 'No response from the bot.' },
      ]);
    } catch (error) {
      console.error('API 1 Error:', error);
    } finally {
      setUserInput('');
      setSelectedImage(null);
      setIsLoading(false);
      setBotProcessing(false);
    }
  };
  const formatBotResponse = (text) => {
    const parts = text.split(/(```.*?```|`.*?`|\*\*.*?\*\*)/s); // Split by code blocks, inline code, and bold text
    return parts.map((part, index) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        // Code block
        const codeContent = part.slice(3, -3).trim();
        const languageMatch = codeContent.match(/^(\w+)\n/); // Check for language header
        const language = languageMatch ? languageMatch[1] : 'plaintext';
        const code = languageMatch ? codeContent.slice(language.length).trim() : codeContent;
  
        return (
          <CodeSnippet key={index} language={language} code={code} />

        );
      }
  
      if (part.startsWith('`') && part.endsWith('`')) {
        // Inline code
        return (
          <code key={index} style={{ backgroundColor: 'inherit', padding: '2px 4px', borderRadius: '3px', fontSize: '90%',color:'purple' }}>
            {part.slice(1, -1)}
          </code>
        );
      }
  
      if (part.startsWith('**') && part.endsWith('**')) {
        // Bold text
        return (
          <span key={index} style={{ fontWeight: 'bold',backgroundColor:'inherit' }}>
            {part.slice(2, -2)}
          </span>
        );
      }
  
      // Plain text
      return <span key={index}>{part}</span>;
    });
  };
  
const CodeSnippet = ({ language, code }) => {
  const [copyStatus, setCopyStatus] = useState('Copy');

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopyStatus('Copied');
      setTimeout(() => setCopyStatus('Copy'), 2000); // Reset after 2 seconds
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div
      style={{
        position: 'relative',
  backgroundColor: theme.palette.mode === "light"
          ? theme.palette.background.default // Grey for light mode
          : theme.palette.background.black, // Black for dark mode
        padding: "10px",
        borderRadius: "5px",
        overflowX: "auto",
        color: theme.palette.text.primary, // Automatically adapt text color
        padding: '10px',
        borderRadius: '5px',
        overflowX: 'auto',
      }}
    >
      <button
        onClick={handleCopy}
        style={{
          position: 'absolute',
          top: '10px',
          right: '10px',
          padding: '5px 10px',
          fontSize: '12px',
          cursor: 'pointer',
          border: 'none',
          backgroundColor: '#9C27B0',
          color: 'inherit',
          borderRadius: '3px',
        }}
      ><ContentCopyIcon 
        fontSize='15px'
     />
        {copyStatus}
      </button>
      <code>{`// ${language}\n${code}`}</code>
    </div>
  );
};

  const handleInputChange = (e) => {
    setUserInput(e.target.value);
  };
  const handleRemoveImage = () => {
    setSelectedImage(null);
  };

  const handleImageChange = (event) => {
    if (event && event.target && event.target.files) {
      const file = event.target.files[0];
      setSelectedImage(file);
    }
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUserId = localStorage.getItem("user_id");
      const storedInputCount = localStorage.getItem("inputCount");
      console.log("Stored User ID:", storedUserId); // Debug log
      console.log("Stored Input Count:", storedInputCount);
      if (storedUserId) {
        setuserId(storedUserId); // Update the state with the userId
      } else {
        console.log("No userId found in localStorage.");
      }
      if (storedInputCount) {
        setInputCount(Number(storedInputCount)); // Parse and set inputCount as a number
      } else {
        console.log("No inputCount found in localStorage.");
      }
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessageToDjango();
  };

  const onHistorySelect = (item) => {
    setSelectedHistory(item); // Update selected history when an item is clicked
    if (historyRef.current) {
      historyRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text);
  };
  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };
  const handleScroll = () => {
    const container = chatContainerRef.current;
    if (container) {
      const isAtBottom = container.scrollHeight - container.scrollTop === container.clientHeight;
      setIsScrolledToBottom(isAtBottom);
    }
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages1]); // Runs whenever messages1 updates

 
  
  let recognition;
  if (window.SpeechRecognition || window.webkitSpeechRecognition) {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.continuous = false;
  } else {
    alert('Your browser does not support Speech Recognition.');
  }

  const startListening = () => {
    if (!recognition) return;

    setIsListening(true);
    recognition.start();

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setUserInput(transcript);
    };

    recognition.onspeechend = () => {
      setIsListening(false);
      recognition.stop();
    };

    recognition.onerror = (event) => {
      setIsListening(false);
      console.error('Speech recognition error:', event.error);
    };
  };
   // Function to stop listening manually (if needed)
   const stopListening = () => {
    if (recognition && isListening) {
      recognition.stop();
      setIsListening(false);
    }
  };
 
 

  return (
    <Box sx={{ display: 'flex', height: '100vh', backgroundColor: 'inherit'}}>
      <Sidebar
        onHistorySelect={onHistorySelect}
        userId={userId}
        isCollapsed={isSidebarCollapsed}
        sx={{
          position: 'fixed',
          zIndex: 10000,
          transition: 'transform 0.3s ease',
          transform: isSidebarCollapsed ? 'translateX(-100%)' : 'translateX(0)',
          width: '240px',
          height: '100px',
        }}
      />
      <Topbar onSidebarToggle={toggleSidebar} />  
      <Box
        ref={chatContainerRef}
        sx={{
          flexGrow: 1,
          backgroundColor: 'primary.main1',
          padding: 2,
          marginLeft: isSidebarCollapsed ? 0 : '240px',
          transition: 'margin-left 0.3s ease',
          borderRadius: '2%',
          marginTop: '70px',
          display: 'flex',
          flexDirection: 'column',
          height: '87vh',
          overflowY:'scroll',
          '@media (max-width: 600px)': {
            marginLeft: 0,
            height:'calc(100%vh-75px)'
          },
        }}
        onScroll={handleScroll}
      >
         {/* Display the selected history response */}
        {selectedHistory ? (
                <Box
                ref={historyRef} // Attach ref to the container
                  sx={{
                    marginBottom: '10px',
                  }}
                >
                  {/* Question Container */}
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'row-reverse', // Align the question to the right
                      alignItems: 'center',
                      marginBottom: '5px',
                      
                    }}
                  >
                    <Box
                      sx={{
                        position: 'relative',
                        backgroundColor: ' #9C27B0',
                        // color: '#333',
                        padding: '10px 15px',
                        borderRadius: '12px',
                        maxWidth: '70%',
                        color:'#fff',
                        wordWrap: 'break-word',
                        whiteSpace: 'pre-wrap',
                        overflowX:'hidden',
                      }}
                    >
                        {selectedHistory.questions}                    
                    </Box>
                  </Box>
                  {/* Response Container */}
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'row', // Align the response to the left
                      alignItems: 'center',
                    }}
                  >
                    <Box
                      sx={{
                        position: 'relative',
                        backgroundColor: 'background.paper',
                        color: 'primary.main2',
                        padding: '10px 15px',
                        borderRadius: '12px',
                        maxWidth: '70%',
                        wordWrap: 'break-word',
                        whiteSpace: 'pre-wrap',
                        overflow: 'hidden',
                      }}
                    >
                        {selectedHistory.gemini_response ? formatBotResponse(selectedHistory.gemini_response) :selectedHistory.gemini_response}

                      {/* Add copy functionality for Gemini response if needed */}
                      <IconButton
                        onClick={() => handleCopy(selectedHistory.gemini_response)}
                        sx={{
                          position: 'absolute',
                          bottom: '5px',
                          right: '0px',
                          color: '#9C27B0',
                          backgroundColor: 'rgba(255, 255, 255, 0.8)',
                          padding: '0px',
                        }}
                      >
                        <ContentCopyIcon />
                      </IconButton>
                    </Box>
                  </Box>
                </Box>
              ) : null}
        <Box sx={{ flexGrow: 1, padding: '10px' }}>    
          {messages1.map((message, index) => (
            <Box
              key={index}
              sx={{
                display: 'flex',
                flexDirection: message.type === 'user' ? 'row-reverse' : 'row',
                alignItems: 'center',
                marginBottom: '10px',
                
              }}
            > 
              <Box
                key={index}
                sx={{
                  position: 'relative', // Ensures child elements (like the button) can be absolutely positioned
                  backgroundColor: message.type === 'user' ? 'background.default1' : '#fff',
                  color: message.type === 'user' ? '#fff' : '#333',
                  padding: '10px 15px',
                  borderRadius: '12px',
                  maxWidth: '70%',
                  wordWrap: 'break-word',
                  whiteSpace: 'pre-wrap', // Preserves line breaks in bot responses
                  overflow: 'hidden', // Ensures no unintended overflow
                
                }}
              >
                  {message.type === 'bot' ? formatBotResponse(message.text) : message.text}
                  {message.type === 'bot' && (
                  <IconButton
                    onClick={() => handleCopy(message.text)}
                    sx={{
                      position: 'absolute', // Positions the button at the bottom-right
                      bottom: '5px', // Aligns with the bottom of the box
                      right: '1px', // Aligns with the right of the box
                      color: '#9C27B0',
                      backgroundColor: 'rgba(255, 255, 255, 0.8)', // Adds slight background for visibility
                      padding: '0px',
                    }}
                  >
                    <ContentCopyIcon />
                  </IconButton>
                )}
              </Box>
            </Box>
          ))}      
           {/* Add a div to mark the end of the messages */}
            <div ref={messagesEndRef} />
        </Box>
           {/* Scroll to Bottom Button */}
        {!isScrolledToBottom && (
          <Button
            onClick={scrollToBottom}
            sx={{
              position: 'fixed',
              bottom: '20px',
              left: '50%', // Center horizontally
              transform: 'translateX(-50%)', // Offset by 50% of the width to truly center it
              backgroundColor: '#1a4163',
              color: '#fff',
              borderRadius: '50%',
              minWidth: '50px',
              height: '50px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.2)',
            }}
          >
            ⬇
          </Button>
        )}
        <Grid container spacing={1} sx={{ alignItems: 'center', padding: '10px' }}>
          <Grid
            item
            xs={12}
            sm={11}
            sx={{
              display: 'flex',
              alignItems: 'center',
              backgroundColor: 'background.paper',
              borderRadius: '25px',
              padding: '5px 15px',
              boxShadow: '0px 2px 5px rgba(0, 0, 0, 0.1)',
              position: 'relative',
            }}
          >
                {/* Upload Icon */}
      <IconButton
        component="label"
        sx={{
          color: "#9C27B0",
          fontSize: "1.5rem",
          cursor: "pointer",
        }}
      >
        <ImImage />
        <input
          type="file"
          hidden
          accept="image/*"
          onChange={handleImageChange}
        />
      </IconButton>
      <Box sx={{ display: "flex", alignItems: "center" }}>
  

        {/* Display selected image */}
        {selectedImage && (
          <Box
            sx={{
              position: "relative",
              display: "inline-block",
              marginLeft: "10px",
            }}
          >
            <img
              src={URL.createObjectURL(selectedImage)}
              alt="Selected"
              style={{ maxWidth: "100px", maxHeight: "50px" }}
            />
            <Button
              onClick={handleRemoveImage}
              sx={{
                position: "absolute",
                top: "0",
                right: "0",
                minWidth: "auto",
                padding: "4px",
                borderRadius: "50%",
                backgroundColor: "inherit",
                fontSize: "0.8rem",
                color: "red",
                cursor: "pointer",
              }}
            >
              X
            </Button>
          </Box>
          )}  
        </Box>   
          <TextField
              fullWidth
              multiline
              maxRows={5} // Maximum 5 rows
              value={userInput}
              onChange={handleInputChange}
              placeholder="Type your text here..."
              variant="outlined"
              InputProps={{
                disableUnderline: true,
                sx: {
                  '& fieldset': {
                    border: 'none',
                    color:'blue',
                  },
                },
              }}
              sx={{
                backgroundColor: 'background.default',
                borderRadius: '8px',
                padding: '10px',
                fontFamily: 'monospace',
                fontSize: '14px',
                whiteSpace: 'pre-wrap',
                minHeight: '80px', // Minimum height when empty
                
                maxHeight: '150px', // Maximum height equivalent to 5 rows
                transition: 'height 0.2s ease-in-out', // Smooth transition for resizing
              }}
            /> 
        <FaMicrophone 
             onClick={isListening ? stopListening : startListening}
             disabled={isListening} 
             style={{
             fontSize: "26px",
             color: '#9C27B0',
             backgroundColor: isListening ? "gray" : "transparent",
             cursor: isListening ? "not-allowed" : "pointer",
           }}
        /> 
        </Grid>
          <Grid item>
            <Button
              onClick={handleSubmit}
              variant="contained"
              sx={{
                backgroundColor: '#1a4163',
                color: '#fff',
                borderRadius: '50%',
                minWidth: '50px',
                height: '50px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
           
              }}
            >
              <IoSend />
            </Button>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

export default App;
