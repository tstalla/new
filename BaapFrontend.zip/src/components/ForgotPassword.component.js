import React, { Component } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';

import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  TextField,
  Typography,
  Alert,
} from '@mui/material';

class ForgotPassword extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      loading: false,
      resetMessage: '',
      errorMessage: '',
    };
  }

  handleGoBack = () => {
    this.props.navigate('/sign-in');
  };

  handleEmailChange = (e) => {
    const email = e.target.value;
    this.setState({ email, errorMessage: '' });
  };

  validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  handleSubmit = async (e) => {
    e.preventDefault();

    const { email } = this.state;

    if (!email) {
      this.setState({ errorMessage: 'Email field cannot be empty.' });
      return;
    }

    if (!this.validateEmail(email)) {
      this.setState({ errorMessage: 'Please enter a valid email address.' });
      return;
    }

    this.setState({ loading: true, resetMessage: '', errorMessage: '' });

    try {
      const apiUrl = 'http://127.0.0.1:8000/forgot_password_otp/';
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        this.setState({ resetMessage: 'Reset code sent successfully!' });
        localStorage.setItem('resetEmail', email);

        this.props.navigate('/reset_password', { state: { email } });
      } else {
        console.error('Failed to send reset code');
        this.setState({
          errorMessage: 'Failed to send reset code. Please try again.',
        });
      }
    } catch (error) {
      console.error('Error occurred while sending reset code:', error);
      this.setState({
        errorMessage: 'An error occurred. Please try again later.',
      });
    } finally {
      this.setState({ loading: false });
    }
  };

  render() {
    const { email, loading, resetMessage, errorMessage } = this.state;

    return (
      <>
      {/* Apply global styles to remove overflow */}
      <style>
        {`
          body, html {
            margin: 0;
            padding: 0;
            overflow: hidden; /* Remove overflow from body */
            height: 100%;
          }
        `}
      </style>
        <Navbar />
        <Box
          sx={{
            position: 'relative',
            backgroundSize: 'cover',
            color:'inherit',
            backgroundPosition: 'center',
            height: '100vh',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            overflow: 'hidden',
          }}
        >
        <Card
            sx={{
              maxWidth: 400,
              width: '90%',
              padding: 4,
              borderRadius: 3,
              boxShadow: 3,
              backgroundImage: 'linear-gradient(to bottom right, #b78dff,rgb(181, 223, 252))', // Use backgroundImage for gradients
              backdropFilter: 'blur(10px)',
              marginBottom:'100px',
            }}
          >
            <CardContent>
              <Typography variant="h5" textAlign="center" gutterBottom>
                Forgot Password
              </Typography>
              <form onSubmit={this.handleSubmit}>
                <TextField
                  fullWidth
                  variant="outlined"
                  label="Email Address"
                  type="email"
                  color='background.paper'
                  value={email}
                  onChange={this.handleEmailChange}
                  error={!!errorMessage}
                  helperText={errorMessage || ' '}
                  sx={{ marginBottom: 0 }}
                />
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="primary"
                  disabled={loading}
                  sx={{
                    marginBottom: 2,
                    position: 'relative',
                    backgroundColor: loading ? '#cccccc' : '#6a2c88', // Set different color when loading and not loading
                    '&:hover': {
                      backgroundColor: loading ? '#cccccc' : '#5a2274', // Set hover color as well
                    },
                  }}
                >
                  {loading ? <CircularProgress size={24} color="inherit" /> : 'Send Code'}
                </Button>
                <Button
                  fullWidth
                  variant="outlined"
                  color="secondary"
                  onClick={this.handleGoBack}
                >
                  Cancel
                </Button>
              </form>

              {resetMessage && (
                <Alert severity="success" sx={{ marginTop: 2 }}>
                  {resetMessage}
                </Alert>
              )}
            </CardContent>
          </Card>
        </Box>
      </>
    );
  }
}

const ForgotPasswordWrapper = () => {
  const navigate = useNavigate();
  return <ForgotPassword navigate={navigate} />;
};

export default ForgotPasswordWrapper;