import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Sidebar from "./Sidebar";
import DashNavbar from "./DashNavbar";
 
axios.defaults.timeout = 100000;
 
function Update() {
    const { id } = useParams();
    const navigate = useNavigate();
 
    const [values, setValues] = useState({
        name: '',
        email: ''
    });
    const readUrl = `http://127.0.0.1:8000/students/read/${id}/`;
    const updateUrl = `http://127.0.0.1:8000/students/update/${id}/`;
   
    useEffect(() => {
        axios.get(readUrl)
            .then(res => {
                setValues(prevValues => ({
                    ...prevValues,
                    name: res.data.name,
                    email: res.data.email
                }));
            })
            .catch(err => console.error('Error fetching data:', err));
    }, [readUrl]);
    const handleUpdate = (event) => {
        event.preventDefault();
        console.log('Updating with data:', values);  // Check the console for data
        axios.put(updateUrl, values)
            .then(res => {
                console.log(res);
                navigate('/crudHome');
            })
            .catch(err => console.log(err));
    };
 
    return (
        <>
            <DashNavbar />
            <Sidebar />
        <div className='auth-inner d-flex bg-dark justify-content-center align-items-center' style={{ width: '100vw' }}>
            <div className='w-50 bg-white rounded p-3'>
                <form onSubmit={handleUpdate}>
                    <h2>Update Candidate</h2>
                    <div className='mb-3 d-flex flex-column align-items-start'>
                        <label className="mb-1">Name</label>
                        <input
                            type="text"
                            placeholder='Enter name'
                            className='form-control'
                            value={values.name}
                            onChange={e => setValues({ ...values, name: e.target.value })}
                        />
                    </div>
                    <div className='mb-3 d-flex flex-column align-items-start'>
                        <label className="mb-1">Email</label>
                        <input
                            type='email'
                            placeholder='Enter email'
                            className='form-control'
                            value={values.email}
                            onChange={e => setValues({ ...values, email: e.target.value })}
                        />
                    </div>
                    <Link to="/crudHome" className="btn btn-primary me-2">Back</Link>
                    <button className='btn btn-success'>Update</button>
                </form>
            </div>
        </div>
        </>
    );
}
 
export default Update;