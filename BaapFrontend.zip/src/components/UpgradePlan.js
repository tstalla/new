import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const UpgradePlan = () => {
  const navigate = useNavigate();
  const [isSubscribed, setIsSubscribed] = useState(false); // Track subscription status

  const plans = [
    {
      name: "Free",
      price: "$0",
      description: "Explore how AI can help you with everyday tasks",
      features: [
        "Assistance with writing, problem-solving, and more",
        "Access to GPT-4o mini",
        "Limited access to GPT‑4o",
        "Limited access to data analysis, file uploads, vision, web browsing, and image generation",
        "Use custom GPTs",
      ],
      buttonText: "Your current plan",
      isCurrent: true,
    },
    {
      name: "Plus",
      price: ["$10/month", "  |  $50/6-months", "  |  $90/12-months"],
      description: "Boost your productivity with expanded access",
      features: [
        "Everything in Free",
        "Early access to new features",
        "Access to OpenAI o1-preview, OpenAI o1-mini",
        "Access to GPT-4o, GPT-4o mini, GPT-4",
        "Up to 5x more messages for GPT‑4o",
        "Access to data analysis, file uploads, vision, web browsing, and image generation",
        "Access to Advanced Voice Mode",
      ],
      buttonText: isSubscribed ? "Subscription" : "Upgrade to Plus", // Change button text based on subscription status
      isCurrent: false,
    },
  ];

  const handleUpgradeClick = () => {
    navigate("/payment2");
  };

  const handleCloseClick = () => {
    navigate(-1); // Goes back to the previous page
  };

  const handleSubscription = () => {
    setIsSubscribed(true); // Set subscription status to true after payment
  };

  return (
    <div style={styles.container}>
      <button style={styles.exitButton} onClick={handleCloseClick}>
        &times;
      </button>
      <h1 style={styles.header}>Upgrade Your Plan</h1>
      <p style={styles.subHeader}>
        Choose a plan that suits your needs and unlock advanced features.
      </p>
      <div style={styles.plansContainer}>
        {plans.map((plan, index) => (
          <div
            key={index}
            style={{
              ...styles.planCard,
              borderColor: plan.isCurrent ? "#007bff" : "#333",
            }}
          >
            <h2 style={styles.planName}>{plan.name}</h2>
            <p style={styles.planPrice}>{plan.price}</p>
            <p style={styles.planDescription}>{plan.description}</p>
            <ul style={styles.featureList}>
              {plan.features.map((feature, i) => (
                <li key={i} style={styles.featureItem}>
                  {feature}
                </li>
              ))}
            </ul>
            <button
              style={{
                ...styles.button,
                backgroundColor: plan.isCurrent ? "#555" : "#007bff",
                color: plan.isCurrent ? "#aaa" : "#fff",
                cursor: plan.isCurrent ? "not-allowed" : "pointer",
              }}
              disabled={plan.isCurrent}
              onClick={!plan.isCurrent ? handleUpgradeClick : undefined}
            >
              {plan.buttonText}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// Styles...
const styles = {
  container: {
    position: "relative",
    width: "100vw",
    height: "100vh",
    margin: "0 auto",
    padding: "20px",
    textAlign: "center",
    backgroundColor: "inherit",
    justifyContent: "center",
    color: "inherit",
    fontFamily: "Arial, sans-serif",
    overflowX:'hidden',
    overflowY:'auto'
  },
  exitButton: {
    position: "absolute",
    top: "10px",
    right: "10px",
    backgroundColor: "inherit",
    border: "none",
    fontSize: "24px",
    color: "inherit",
    cursor: "pointer",
    fontWeight: "bold",
  },
  header: {
    fontSize: "32px",
    marginBottom: "10px",
  },
  subHeader: {
    fontSize: "16px",
    color: "#aaa",
    marginBottom: "30px",
  },
  plansContainer: {
    height: "80vh",
    display: "flex",
    justifyContent: "center",
    flexWrap: "wrap",
    gap: "100px",
  },
  planCard: {
    backgroundColor: "inherit",
    color:'inherit',
    border: "2px solid",
    borderRadius: "10px",
    height: "480px",
    width: "400px",
    padding: "20px",
    textAlign: "left",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    transition: "transform 0.3s ease, box-shadow 0.3s ease",
  },
  planName: {
    fontSize: "20px",
    marginBottom: "5px",
    color: "inherit",
  },
  planPrice: {
    fontSize: "24px",
    margin: "10px 0",
    fontWeight: "bold",
    color: "inherit",
  },
  planDescription: {
    fontSize: "14px",
    marginBottom: "20px",
    color: "inherit",
  },
  featureList: {
    listStyleType: "none",
    padding: 0,
    marginBottom: "20px",
  },
  featureItem: {
    fontSize: "14px",
    marginBottom: "10px",
    display: "flex",
    alignItems: "center",
    color: "inherit",
  },
  button: {
    width: "100%",
    padding: "10px 0",
    border: "none",
    borderRadius: "5px",
    fontSize: "16px",
    transition: "background-color 0.3s ease",
  },
};

export default UpgradePlan;
