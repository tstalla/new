import React, { Component, useState, useEffect } from "react";
import "./dash.css";

import InputSvg from "./send_icon.svg"; import DashNavbar from "./DashNavbar";


export default class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      messages: [],
      userInput: "",
    };
  }

  autoExpand = (e) => {
    e.target.style.height = 'auto';
    e.target.style.height = e.target.scrollHeight + 'px';
    this.setState({ userInput: e.target.value });
  };

  sendMessageToDjango = async () => {
    const { userInput } = this.state;

    try {
      const response = await fetch("http://127.0.0.1:8000/api1_chat/", {
        method: "POST",
        body: JSON.stringify({ user_input: userInput }),
        
      });

      if (!response.ok) {
        throw new Error("Failed to fetch");
      }
      //const result = await response.json();
      const responseData = await response.json();
      console.log("API Response:", responseData);

      this.setState((prevState) => ({
        messages: [...prevState.messages, ...responseData],
        userInput: "",
      }));
    } catch (error) {
      console.error("Error sending message:", error.message);
    }
  };



  handleInputChange = (e) => {
    this.setState({ userInput: e.target.value });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    this.sendMessageToDjango();
  };

  handleImageClick = () => {
    this.sendMessageToDjango();
  };

  TypingEffect = ({ message, isBot, typingSpeed }) => {
    const [visibleChars, setVisibleChars] = useState(0);

    useEffect(() => {
      const interval = setInterval(() => {
        setVisibleChars((prevVisibleChars) => {
          const nextVisibleChars = prevVisibleChars + 1;
          if (nextVisibleChars > message.length) {
            clearInterval(interval);
          }
          return nextVisibleChars;
        });
      }, typingSpeed || 20); // Adjusted to the typing speed (100ms)

      return () => clearInterval(interval);
    }, [message, typingSpeed]);

    return (
      <div className={`message ${isBot ? 'bot' : 'user'}`}>
        <div className={`message-box ${isBot ? 'bot-message-box' : 'user-message-box'}`}>
          <div className="message-content">
            <div className={`message-text ${isBot ? 'typing-effect' : ''}`}>
              {message.substring(0, visibleChars)}
              {isBot && <span className="cursor"></span>}
            </div>
          </div>
        </div>
      </div>
    );
  };

  render() {
    const { messages, userInput } = this.state;
    const { TypingEffect } = this;

    return (
      <>
        <DashNavbar />
        <div className="container mt-5">
          <div className="row">
            <div className="col-sm-4 mb-3 mr-2">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">GPT API 1</h5>
                  <div className="chat-container">
                    <div id="chat-messages">
                      {messages.map((message, index) => (
                        <div key={index} className={`message ${message[1] ? 'bot' : 'user'}`}>
                          {message[1] ? (
                            <div className=" bot-message-box">
                              <div className="message-content" >
                                <div className="user-icon" style={{ display: 'flex', alignItems: 'center' }}>
                                  <img src={"https://st4.depositphotos.com/20523356/22445/v/450/depositphotos_224458102-stock-illustration-flat-user-icon-face-avatar.jpg"} alt="User" style={{ width: '40px', height: '40px' }} />
                                  <div className="text-right">User</div>
                                </div>
                                <div className="message-box message-image">
                                  {/* Add your bot image here */}

                                  {message[0]}
                                </div>
                                <div className="message-text">
                                  <div className="message-image" >
                                    <div className="bot-icon" style={{ display: 'flex', alignItems: 'center'  }}>
                                      <div className="text-left">Baap</div>
                                      <img src={"https://i.pinimg.com/564x/07/05/5d/07055d8a583396e3556dedc92c321e30.jpg"} alt="Bot Icon" style={{ width: '30px', height: '30px' }} />
                                      <div className="text-right">GPT</div>
                                    </div>
                                    <TypingEffect message={message[1]} isBot={true} typingSpeed={0} />
                                  </div>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="message-content user-message-box">
                              <div className="message-image">
                                {/* Add your user image here */}
                                <img src={process.env.PUBLIC_URL + "/path/to/user-image.png"} alt="User" style={{ width: '20px', height: '20px' }} />
                              </div>
                              <div className="message-text">
                                {message[1]}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}

                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-sm-4 mb-3 ">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">GPT API 2</h5>
                  <p className="card-text">
                    With supporting text below as a natural lead-in to
                    additional content.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-4 mb-3 ">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">GPT API 3</h5>
                  <p className="card-text">
                    With supporting text below as a natural lead-in to
                    additional content.
                  </p>
                </div>
              </div>
            </div>

            {/* ... (other GPT API cards) ... */}
            <div className="col-12 mt-3 d-flex justify-content-center">
              <form
                onSubmit={this.handleSubmit}
                className="mb-3 d-flex align-items-center border border-secondary Input-box"
              >
                <div className="input-group">
                  <textarea
                    className="form-control form-control-lg input-bar auto-expand"
                    placeholder="Message BaapGPT..."
                    aria-label=".form-control-lg example"
                    rows="1"
                    value={userInput}
                    onChange={this.handleInputChange}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        this.handleSubmit(e);
                      }
                    }}
                    maxLength={10000}
                  />
                </div>
                <img
                  src={InputSvg}
                  className="InputSvg"
                  onClick={this.handleImageClick}
                  alt="Send Icon"
                />
              </form>
            </div>
          </div>
        </div>
      </>
    );
  }
}