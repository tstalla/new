import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserProfile = ({ userId }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  
  useEffect(() => {
    // Fetch user data when the component loads
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/UserProfile/${userId}`);
        if (response.data.user_data) {
          setName(response.data.user_data.name);
          setEmail(response.data.user_data.email);
        } else {
          setMessage('User not found');
        }
      } catch (error) {
        setMessage('Error fetching data');
      }
    };

    fetchUserData();
  }, [userId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const userData = { name, email };

    try {
      const response = await axios.put(`http://127.0.0.1:8000/UserProfile/${userId}`, userData, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.data.message === 'User profile updated successfully.') {
        setMessage('Profile updated successfully');
      } else {
        setMessage('Error updating profile');
      }
    } catch (error) {
      setMessage('Error updating data');
    }
  };ssss

  return (
    <div>
      <h1>Update User Profile</h1>
      {message && <p>{message}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
};

export default UserProfile;
