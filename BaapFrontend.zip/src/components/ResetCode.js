import React, { Component } from "react";
import { useNavigate } from "react-router-dom";
import { Container, TextField, Button, Box, Typography, IconButton } from "@mui/material";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import Navbar from "./Navbar";
import Swal from "sweetalert2"; // Import Swal

class ResetCode extends Component {
  constructor(props) {
    super(props);
    this.state = {
      otp: "",
      newPassword: "",
      confirmPassword: "",
      successMessage: "",
      errorMessage: "",
      showPassword: false,
      showConfirmPassword: false,
      resendOtpDisabled: true,
      timer: 60,
    };
    this.timerInterval = null;
  }

  componentDidMount() {
    this.startResendOtpTimer();
  }

  componentWillUnmount() {
    clearInterval(this.timerInterval);
  }

  startResendOtpTimer = () => {
    this.setState({ resendOtpDisabled: true, timer: 90 });
    this.timerInterval = setInterval(() => {
      this.setState((prevState) => {
        if (prevState.timer <= 1) {
          clearInterval(this.timerInterval);
          return { timer: 0, resendOtpDisabled: false };
        }
        return { timer: prevState.timer - 1 };
      });
    }, 1000);
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value, errorMessage: "" });
  };

  togglePasswordVisibility = (field) => {
    this.setState((prevState) => ({
      [field]: !prevState[field],
    }));
  };

  handleSubmit = async (e) => {
    e.preventDefault();
    const { otp, newPassword, confirmPassword } = this.state;

    if (!otp || !newPassword || !confirmPassword) {
      this.setState({ errorMessage: "All fields are required." });
      return;
    }

    if (newPassword !== confirmPassword) {
      this.setState({ errorMessage: "Passwords do not match." });
      return;
    }

    try {
      const apiUrl = "http://127.0.0.1:8000/reset_password/";
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          otp,
          new_password: newPassword,
          confirm_new_password: confirmPassword,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        this.setState({ successMessage: "Password reset successfully!", errorMessage: "" });
        Swal.fire({
          title: "Success!",
          text: "Your password has been reset successfully.",
          icon: "success",
          confirmButtonText: "OK",
        });
        this.props.navigate('/sign-in');
      } else {
        this.setState({ errorMessage: data.error || "Failed to reset password. Please try again." });
      }
    } catch (error) {
      this.setState({ errorMessage: "An error occurred. Please try again later." });
      Swal.fire({
        title: "Failed!",
        text: "Your password reset has been failed.",
        icon: "failed",
        confirmButtonText: "NO",
      });
    }
  };

  handleResendOtp = async () => {
    const email = localStorage.getItem("resetEmail");

    if (!email) {
      this.setState({ errorMessage: "Email is missing. Please try again." });
      return;
    }

    try {
      const apiUrl = "http://127.0.0.1:8000/resend_otp/";
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (response.ok) {
        this.setState({ successMessage: data.message, errorMessage: "" });
        this.startResendOtpTimer();
      } else {
        this.setState({ errorMessage: data.error || "Failed to resend OTP. Please try again." });
      }
    } catch (error) {
      this.setState({ errorMessage: "An error occurred while resending OTP." });
    }
  };

  render() {
    const {
      otp,
      newPassword,
      confirmPassword,
      successMessage,
      errorMessage,
      showPassword,
      showConfirmPassword,
      resendOtpDisabled,
      timer,
      loading
    } = this.state;
  
    return (
      <>
      {/* Apply global styles to remove overflow */}
      <style>
        {`
          body, html {
            margin: 0;
            padding: 0;
            overflow: hidden; /* Remove overflow from body */
            height: 100%;
          }
        `}
      </style>
        <Navbar />
        <Container
          maxWidth="sm"
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "100vh",
            backgroundColor: "inherit",
            
          }}
        >
          <Box
            sx={{
              width: "80%",
              padding: 4,
              backgroundImage: 'linear-gradient(to bottom right, #b78dff,rgb(181, 223, 252))', // Use backgroundImage for gradients
              borderRadius: 2,
              boxShadow: 3,
              textAlign: "center",
              marginBottom:'50px',
            }}
          >
            <Typography variant="h5" gutterBottom>
              Reset Password
            </Typography>
            <form onSubmit={this.handleSubmit}>
              <TextField
                fullWidth
                label="OTP"
                name="otp"
                value={otp}
                onChange={this.handleChange}
                variant="outlined"
                margin="normal"
                required
              />

              <Box sx={{ position: "relative" }}>
                <TextField
                  fullWidth
                  label="New Password"
                  name="newPassword"
                  value={newPassword}
                  onChange={this.handleChange}
                  variant="outlined"
                  margin="normal"
                  type={showPassword ? "text" : "password"}
                  required
                />
                <IconButton
                  onClick={() => this.togglePasswordVisibility("showPassword")}
                  sx={{ position: "absolute", top: "50%", right: 10, transform: "translateY(-50%)" }}
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </Box>

              <Box sx={{ position: "relative" }}>
                <TextField
                  fullWidth
                  label="Confirm Password"
                  name="confirmPassword"
                  value={confirmPassword}
                  onChange={this.handleChange}
                  variant="outlined"
                  margin="normal"
                  type={showConfirmPassword ? "text" : "password"}
                  required
                />
                <IconButton
                  onClick={() => this.togglePasswordVisibility("showConfirmPassword")}
                  sx={{ position: "absolute", top: "50%", right: 10, transform: "translateY(-50%)" }}
                >
                  {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </Box>

              {errorMessage && (
                <Typography color="error" variant="body2" sx={{ mt: 2 }}>
                  {errorMessage}
                </Typography>
              )}
              {successMessage && (
                <Typography color="success" variant="body2" sx={{ mt: 2 }}>
                  {successMessage}
                </Typography>
              )}

              <Box sx={{ mt: 2 }}>
                <Button
                  fullWidth
                  type="submit"
                  variant="contained"
                  color="primary"
                  disabled={loading}
                  sx={{ padding: "10px", fontSize: "1rem",
                    backgroundColor: loading ? '#cccccc' : '#6a2c88', // Set different color when loading and not loading
                    '&:hover': {
                      backgroundColor: loading ? '#cccccc' : '#5a2274', // Set hover color as well
                    }
                   }}
                >
                  Reset Password
                </Button>
              </Box>

              <Button
                fullWidth
                variant="text"
                onClick={this.handleResendOtp}
                disabled={resendOtpDisabled}
                sx={{ mt: 2 }}
              >
                {resendOtpDisabled ? `Resend OTP (${timer}s)` : "Resend OTP"}
              </Button>
            </form>
          </Box>
        </Container>
      </>
    );
  }
}

// Functional wrapper to provide navigate
const ResetCodeWrapper = () => {
  const navigate = useNavigate();
  return <ResetCode navigate={navigate} />;
};

export default ResetCodeWrapper;
