import React, { useState, useEffect } from "react";
import axios from "axios";
import AuthService from "./authService";
import { TextField, Button, Box, Typography, Link } from "@mui/material";
import { useNavigate, useLocation } from "react-router-dom";
import Swal from "sweetalert2";
import ChatBotAmico from "../Images/ChatBotAmico.svg"; // Chatbot Illustration
import SigninText from "../Images/Frame-1171276064.png"; // Sign-in Text Image
import Navbar from "./Navbar"; // Navbar Component
import { FcGoogle } from "react-icons/fc";
import { GoogleLogin, GoogleOAuthProvider } from "@react-oauth/google";

const Signin = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState("");
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [verificationMessage, setVerificationMessage] = useState(""); // Added state for verification message
  const location = useLocation(); // Access location for URL parameters

  useEffect(() => {
    const savedEmail = localStorage.getItem("rememberedEmail");
    const savedPassword = localStorage.getItem("rememberedPassword");
    if (savedEmail && savedPassword) {
      setFormData({ email: savedEmail, password: savedPassword });
      setRememberMe(true);
    }
  }, []);
  useEffect(() => {
    // Check if a verification message exists in localStorage
    const storedMessage = localStorage.getItem("verificationMessage");
    if (storedMessage) {
      setErrorMessage(storedMessage);
      localStorage.removeItem("verificationMessage"); // Remove after displaying
    }
  }, []);
  useEffect(() => {
    // Check if 'verification' query parameter is in the URL
    const params = new URLSearchParams(location.search);
    const verificationStatus = params.get("verification");

    if (verificationStatus === "success") {
      setVerificationMessage(
        "Email successfully verified! Now you can log in."
      );
    }
  }, [location]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleRememberMeChange = (e) => {
    setRememberMe(e.target.checked);
  };

  const toggleShowPassword = () => setShowPassword(!showPassword);

  const handleLogin = (event) => {
    event.preventDefault();

    AuthService.login(formData.email, formData.password);

    axios
      .post("http://127.0.0.1:8000/Login_view/", formData, { timeout: 100000 })
      .then((response) => {
        const {
          name: userName,
          id: userId,
          daily_api_count: inputCount,
        } = response.data.user;

        localStorage.setItem("userName", userName);
        localStorage.setItem("user_id", userId);
        localStorage.setItem("email", formData.email);
        if (inputCount !== undefined) {
          localStorage.setItem("inputCount", inputCount);
        }

        if (rememberMe) {
          localStorage.setItem("rememberedEmail", formData.email);
          localStorage.setItem("rememberedPassword", formData.password);
        } else {
          localStorage.removeItem("rememberedEmail");
          localStorage.removeItem("rememberedPassword");
        }

        Swal.fire({
          icon: "success",
          title: "Login Successful!",
          text: "Welcome!",
          timer: 1000,
          timerProgressBar: true,
          showConfirmButton: false,
        });

        navigate("/dashboard");
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Login Error",
          text: "Invalid email or password. Please try again.",
        });
      });
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "100vh", // Reduced page height
        backgroundColor: "inherit",
      }}
    >
      <Navbar authenticated={false} setAuthenticated={() => {}} />

      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: "center",
          justifyContent: "space-evenly",
          flexGrow: 1,
          padding: 2,
        }}
      >
        {/* Left Section - Images */}
        <Box
          sx={{
            flex: 1,
            display: { xs: "none", sm: "flex" }, // Hide on small screens
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            textAlign: "center",
            marginBottom: { xs: 3, md: 0 },
          }}
        >
          <img
            src={ChatBotAmico}
            alt="Chatbot Illustration"
            style={{
              maxWidth: "40%",
              maxHeight: "450px", // Added max height for better visibility
              marginBottom: "8px",
            }}
          />
          <img
            src={SigninText}
            alt="Join The Chat Revolution"
            style={{
              maxWidth: "30%",
              maxHeight: "120px", // Adjusted height
              marginTop: "8px",
            }}
          />
        </Box>

        {/* Right Section - Form */}
        <Box
          component="form"
          onSubmit={handleLogin}
          sx={{
            flex: 1,
            padding: { xs: 2, sm: 5 },
            background: "linear-gradient(to bottom right, #b78dff, #a8d8f8)",
            borderRadius: "15px",
            width: { xs: "80%", sm: "50%", md: "40%" },
            maxWidth: "400px",
            boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
            margin: { xs: "auto", sm: "unset" },
            maxHeight: { xs: "70%", sm: "none" }, // Set maxHeight for small screens
          }}
        >
          <Typography
            variant="h5"
            gutterBottom
            sx={{ color: "inherit", textAlign: "center" }}
          >
            Welcome To Your Account
          </Typography>
          {/* Error Message Display */}
          {errorMessage && (
            <Typography
              variant="body2"
              sx={{
                color: "blue",
                textAlign: "center",
                marginBottom: 2,
              }}
            >
              {errorMessage}
            </Typography>
          )}

          {/* Display Verification Message if available */}
          {verificationMessage && (
            <Typography
              variant="body2"
              sx={{
                color: "green",
                textAlign: "center",
                marginBottom: 2,
              }}
            >
              {verificationMessage}
            </Typography>
          )}

          <TextField
            placeholder="Email Address"
            variant="outlined"
            fullWidth
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            margin="normal"
            sx={{
              backgroundColor: "background.paper",
              borderRadius: "10px",
              marginBottom: 2,
            }}
          />

          <TextField
            placeholder="Password"
            variant="outlined"
            fullWidth
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            margin="normal"
            type={showPassword ? "text" : "password"}
            sx={{
              backgroundColor: "background.paper",
              borderRadius: "10px",
              marginBottom: 2,
            }}
            InputProps={{
              endAdornment: (
                <Button
                  onClick={toggleShowPassword}
                  sx={{ textTransform: "none" }}
                >
                  {showPassword ? "Hide" : "Show"}
                </Button>
              ),
            }}
          />

          <Box sx={{ display: "flex", alignItems: "center", marginTop: 1 }}>
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={handleRememberMeChange}
              style={{ marginRight: 8 }}
            />
            <Typography
              variant="body2"
              sx={{ color: "#inherit", marginRight: 2 }}
            >
              Remember Me
            </Typography>

            <Typography
              component="a"
              href="/forgotPass"
              sx={{
                color: "blue",
                fontSize: { xs: "0.8rem", sm: "0.9rem", md: "1rem" },
                textDecoration: "none",
                ml: { xs: "auto", sm: 2, md: 4 }, // Adds margin-left to move further right
                "&:hover": {
                  textDecoration: "underline",
                },
              }}
            >
              Forgot Password?
            </Typography>
          </Box>

          <Button
            type="submit"
            variant="contained"
            fullWidth
            sx={{
              marginTop: 2,
              backgroundColor: "#6a2c88",
              borderRadius: "10px",
              color: "white",
              "&:hover": {
                backgroundColor: "#5a2274",
              },
            }}
          >
            Sign In
          </Button>

          {/* <Button
            onClick={() => {
              const clientId = "523367539354-tj2025kn6tv3o5kptaok4n1ue0qt9m9b.apps.googleusercontent.com";
              const redirectUri = "http://localhost:3001/dashboard";
              const scope = "email profile openid";
              const googleAuthUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${encodeURIComponent(
                redirectUri
              )}&response_type=token&scope=${encodeURIComponent(scope)}&include_granted_scopes=true`;

              window.location.href = googleAuthUrl;
              console.log("Google Auth URL:", googleAuthUrl);
            }}
            startIcon={  <FcGoogle  />}
            sx={{
              marginTop: 2,
              borderColor: "#4285F4",
              color: "#4285F4",
            
              display: "block",  // Makes the button behave like a block element
              marginLeft: "auto",  // Centers the button
              marginRight: "auto", // Centers the button
            }}
          >
         
          </Button> */}
          {/* <GoogleOAuthProvider clientId="950568526445-b3d1a37uck6erdie8asrlnuv23r8j9b1.apps.googleusercontent.com">
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                marginTop: 2, // Spacing above the button
              }}
            >
              <GoogleLogin
                onSuccess={handleSuccess}
                onError={handleError}
                useOneTap={false} // Disable One-Tap Login
                prompt="select_account" // Force Google to ask for account selection
                theme="outline" // Optional: Button theme
                size="medium" // Optional: Button size
              />
            </Box>
          </GoogleOAuthProvider> */}

          <Box sx={{ textAlign: "center", marginTop: 2 }}>
            <Typography variant="body2" sx={{ color: "inherit" }}>
              New Here?{" "}
              <Link
                href="/sign-up"
                sx={{ color: "blue", textDecoration: "none" }}
              >
                Create Account
              </Link>
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Signin;
