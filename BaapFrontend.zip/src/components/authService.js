import axios from 'axios';
 
const AuthService = {
  isAuthenticated: localStorage.getItem('authenticated') === 'true',
 
  initializeAuth: async () => {
    try {
      // Check localStorage to see if the user is authenticated
      const authenticated = localStorage.getItem('authenticated') === 'true';
      AuthService.isAuthenticated = authenticated;
    } catch (error) {
      console.error('Authentication initialization error:', error);
    }
  },
 
  login: async (email, password) => {
    try {
      const response = await axios.post('http://127.0.0.1:8000/Login_view/', {
        email: email,
        password: password,
      }, { timeout: 100000 });
 
      if (response.data.message === 'Login successful') {
        AuthService.isAuthenticated = true;
        localStorage.setItem('authenticated', 'true');
      } else {
        console.error('Login Error:', response.data.error_message);
      }
    } catch (error) {
      console.error('Login Error:', error);
    }
  },
 
  logout: async () => {
    try {
      const token = localStorage.getItem('token'); // Retrieve the token from localStorage
      if (!token) {
        console.error('No token found, cannot logout.');
        return;
      }
  
      const config = {
        headers: {
          Authorization: `Bearer ${token}`, // Include the token in the headers
        },
        timeout: 100000,
      };
  
      await axios.post('http://127.0.0.1:8000/logout/', {}, config); // Pass headers in the config
      AuthService.isAuthenticated = false;
    


      console.log('Logged out successfully.');
    } catch (error) {
      console.error('Logout Error:', error.response ? error.response.data : error.message);
    }
  }
}
  
 
export default AuthService;