import React, { useEffect, useState } from 'react';
import { Box, Typography, Divider,Button,List, ListItemText, Tooltip } from '@mui/material';
import { MdLogout } from "react-icons/md";
import AuthService from "./authService";
import ListItem from '@mui/material/ListItem'; // Ensure correct import from MUI


const Sidebar = ({ isCollapsed ,onHistorySelect }) => {
  const [userId, setUserId] = useState(null);
  const [historyData, setHistoryData] = useState({
    today_history: [],
    yesterday_history: [],
    last_five_days_history: [],
    last_thirty_days_history: [],
  });

   // Load user ID from localStorage
   useEffect(() => {
    const storedUserId = localStorage.getItem("user_id");
    if (storedUserId) {
      setUserId(storedUserId);
    } else {
      console.error("User ID not found in localStorage.");
    }
  }, []);

  // Fetch history data for the user
  useEffect(() => {
    if (userId) {
      fetch(`http://127.0.0.1:8000/api/history/${userId}/`)
        .then((response) => {
          if (!response.ok) throw new Error("Network response was not ok");
          return response.json();
        })
        .then((data) => {
          setHistoryData({
            today_history: data.today_history,
            yesterday_history: data.yesterday_history,
            last_five_days_history: data.last_five_days_history,
            last_thirty_days_history: data.last_thirty_days_history,
          });
        })
        .catch((error) => console.error("Error fetching history:", error));
    }
  }, [userId]);

  // Handle click on history items
  const handleHistoryClick = (item) => {
     onHistorySelect(item);
    console.log("clicked",item)
  };

  const renderHistoryItems = (items) => {
    return items.length > 0 ? (
      [...items].reverse().map((item, index) => (
        <Tooltip title={new Date(item.created_at).toLocaleDateString()} key={index} arrow>
          <ListItem
            button
            onClick={() => handleHistoryClick(item)}
            sx={{
              '&:hover': { backgroundColor: '' }, // Hover effect
              textAlign: 'center',
              cursor:'pointer',
            }}
          >
            <ListItemText
              primary={
                item.questions.length > 20
                  ? `${item.questions.substring(0, 20)}...`
                  : item.questions
              }
              style={{
                textAlign: 'center',
                display: 'block',
              }}
            />
          </ListItem>
        </Tooltip>
      ))
    ) : (
      <ListItem>
        <ListItemText
          primary="No history available"
          style={{ textAlign: 'center', color: 'rgb(218, 218, 222)' }}
        />
      </ListItem>
    );
  };

  const handleLogout = async () => {
    try {
      await AuthService.logout();
      AuthService.isAuthenticated = false;
      window.location.reload(); // Reload the page to ensure a fresh state
    } catch (error) {
      console.error("Logout Error:", error);
    }
  };


  return (
    <Box sx={{ display: 'flex', height: '100vh' }}>
      {/* Sidebar */}
      <Box
        sx={{
          width: isCollapsed ? '0' : '230px', // Sidebar width changes based on collapse state
          borderRadius: '8%',
          background: 'linear-gradient(to bottom, #8EC5FC,rgb(129, 94, 161))',
          color: '#fff',
          transition: 'width 0.3s ease', // Smooth transition for width
          overflow: 'hidden',
          flexShrink: 0,
          height: '85%', // Height of the sidebar matches the topbar height
          position: 'fixed',
          top: '70px', // Position sidebar below the topbar
          boxShadow: isCollapsed ? 'none' : '2px 0 5px rgba(0,0,0,0.1)', // Add shadow when expanded
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          zIndex:1000,
          height: 'calc(100vh - 64px)', // Dynamically calculated height
          
        }}
        onWheel={(e) => {
          e.currentTarget.scrollTop += e.deltaY; // Allow scrolling with mouse wheel
        }}
      >
        {/* Sidebar Header */}
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            p: 2,
            // borderBottom: '1px solid #fff',
            width: '100%',
            justifyContent: 'center',
          }}
        >
          {/* Toggle Button */}
          {!isCollapsed && (
            <Typography variant="h6" sx={{ ml: 1,color:'black' }}>
              History
            </Typography>
          )}
        </Box>

        {/* History Sections */}
        {!isCollapsed && (
          <Box sx={{ padding: 2, width: '100%' }}>
            {/* Today's History */}
          
          <Box>
            <h5 style={{ padding: "0px 16px", textAlign: "center",color:'black' }}>Today's History</h5>
            {renderHistoryItems(historyData.today_history)}
          </Box>
             <Divider sx={{ mb: 1, borderColor: 'black' }} />
            {/* Yesterday's History */}
            <Box>
            <h5 style={{ padding: "0px 16px", textAlign: "center",color:'black' }}>Yesterday's History</h5>
            {renderHistoryItems(historyData.yesterday_history)}
          </Box>
             <Divider sx={{ mb: 1, borderColor: 'black' }} />

            {/* Last 5 Days History */}
            <Box>
            <h5 style={{ padding: "0px 16px", textAlign: "center",color:'black' }}>Last 5 Days</h5>
            {renderHistoryItems(historyData.last_five_days_history)}
          </Box>
             <Divider sx={{ mb: 1, borderColor: 'black' }} />

              {/* Last 30 Days History */}
            <Box>
            <h5 style={{ padding: "0px 16px", textAlign: "center",color:'black' }}>Last 30 Days</h5>
            {renderHistoryItems(historyData.last_thirty_days_history)}
          </Box>
             <Divider sx={{ mb: 1, borderColor: 'black' }} />

          </Box>
        )}
        
        <Button onClick={handleLogout}
          variant="contained"
          sx={{
            background: 'linear-gradient(45deg, #1a4163, #457b9d)',
            color: '#fff',
            borderRadius: '50px',
            padding: '10px 20px',
            fontSize: '1rem',
            fontWeight: 'bold',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '10px', // Adds space between the text and icon
            boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)',
            transition: 'transform 0.2s, box-shadow 0.2s',
            marginTop:'100px',
            '&:hover': {
              background: 'linear-gradient(45deg, #457b9d, #1a4163)',
              transform: 'scale(1.05)',
              boxShadow: '0px 6px 12px rgba(0, 0, 0, 0.3)',
            },
          }}
        >
          Log out
          <MdLogout style={{ fontSize: '1.8rem' }} /> {/* Increased icon size */}
        </Button>
        
      </Box>
    </Box>
  );
};

export default Sidebar;
