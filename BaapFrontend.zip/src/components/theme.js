import { createTheme } from "@mui/material/styles";
 
export const lightTheme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#3399ff", 
       main1: "rgb(219, 245, 245)",
       buttons:"#3399ff",
    },
    background: {
      default: "#f5f5f5", // Light gray
      paper: "#ffffff", // White
      default1:'#9C27B0',
     
    },
  },
});
 
export const darkTheme = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#90caf9", // Light blue
      main2:'#fff',
    },
    background: {
      default: "#121212", // Dark gray
      paper: "#1e1e1e", // Slightly lighter gray
      black:'#000000'
    },
  },
});
 