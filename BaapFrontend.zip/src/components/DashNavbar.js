import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Avatar,
  AppBar,
  Toolbar,
  IconButton,
  Menu,
  MenuItem,
  Typography,
  Box,
  Button,
  Switch,
} from "@mui/material";
import {
  FaUser,
  FaCog,
  FaSignOutAlt,
  FaShareAlt,
} from "react-icons/fa";
import { GiUpgrade } from "react-icons/gi";
import { BsChatSquareDots } from "react-icons/bs";
import { styled } from "@mui/material/styles";
import axios from "axios";
import AuthService from "./authService";
import ProfileModal from "./ProfileModal";
import Baapgpt from './Baapgpt.png';
import KeyboardDoubleArrowDownIcon from '@mui/icons-material/KeyboardDoubleArrowDown';

const DashNavbar = () => {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const [secondMenuAnchorEl, setSecondMenuAnchorEl] = useState(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [userData, setUserData] = useState(null);
  const [profilePictureBlobURL, setProfilePictureBlobURL] = useState(null);
  const [isChatEnabled, setIsChatEnabled] = useState(false);

  useEffect(() => {
    const userId = localStorage.getItem("user_id");
    const tempEmail = localStorage.getItem("email");
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/UserProfile/${userId}`, {
          email: tempEmail,
        });
        setUserData(response.data.user_data);
      } catch (error) {
        console.error("Error fetching user data:", error.message);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (userData && !userData.profile_picture) {
      const fetchProfilePicture = async () => {
        try {
          const response = await axios.get(
            `http://127.0.0.1:8000/get-profile-picture/${userData.id}/`,
            { responseType: "blob" }
          );
          const blobURL = URL.createObjectURL(response.data);
          setProfilePictureBlobURL(blobURL);
        } catch (error) {
          console.error("Error fetching profile picture:", error.message);
        }
      };

      fetchProfilePicture();
    }
  }, [userData]);

  const handleLogout = async () => {
    try {
      // Call the logout method from AuthService
      await AuthService.logout();
      // Update authentication state directly
      AuthService.isAuthenticated = false;
      localStorage.setItem("authenticated", "false");
      // Redirect to the sign-in page after successful logout
      navigate("/sign-in");
    } catch (error) {
      console.error("Logout Error:", error);
      // Handle logout error if needed
    }
   
   localStorage.removeItem('authenticated');
      // localStorage.removeItem('userName');
      localStorage.removeItem('email');
      localStorage.removeItem('user_id');
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleSecondMenuOpen = (event) => {
    setSecondMenuAnchorEl(event.currentTarget);
    
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleSecondMenuClose = () => {
    setSecondMenuAnchorEl(null);
  };

  const toggleChat = () => {
    setIsChatEnabled((prev) => !prev);
    navigate(isChatEnabled ? "/dashboard" : "/chatpage");
  };

  const handleProfileClick = () => {
    setShowProfileModal(true);
        handleMenuClose(); // Close the menu when the profile is clicked

    
  };

  const handleShare = async (contentToShare) => {
    if (navigator.share) {
      // If Web Share API is supported
      try {
        await navigator.share({
          title: 'Shared from My App',
          text: contentToShare,
          url: window.location.href, // Share the current URL
        });
       
      } catch (error) {
        console.error('Error sharing content:', error);
      }
    } else {
      // Fallback: Copy to clipboard
      navigator.clipboard.writeText(contentToShare).then(
       
      );
    }
  }

  return (
    <>
        <ProfileModal
          show={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          userName={userData?.name}
        />
      
    <AppBar position="static" sx={{ backgroundColor: "#121212" }}>
      <Toolbar>
       
          <img
            src={Baapgpt}
            alt="BaapGPT Logo"
            style={{ width: 40, height: 40, marginRight: 8, borderRadius: "50%" }}
          />
           <Box
          sx={{ display: "flex", alignItems: "center", cursor: "pointer" }}
          onClick={() => navigate("/sign-in")}
        >
          <Typography variant="h6">BaapGPT</Typography>
        </Box>
        <IconButton color="inherit" onClick={handleSecondMenuOpen}>
         <KeyboardDoubleArrowDownIcon />
        </IconButton>
        <Box sx={{ flexGrow: 1 }} />

        <Typography
          variant="body1"
          sx={{ marginRight: 2, fontStyle: "italic" }}
        >
          {userData ? `Welcome, ${userData.name}` : "Welcome, User"}
        </Typography>

        <IconButton color="inherit" onClick={handleMenuOpen}>
          <Avatar
            src={profilePictureBlobURL || userData?.profile_picture}
            alt="Profile"
          />
        </IconButton>

        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
        >
          <MenuItem onClick={handleProfileClick} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <FaUser style={{ marginRight: "8px" }} />
            Profile
          </MenuItem>

          <MenuItem onClick={() => navigate("/setting")} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <FaCog style={{ marginRight: "8px" }} />
            Settings
          </MenuItem>

          <MenuItem onClick={handleLogout} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <FaSignOutAlt style={{ marginRight: "8px" }} />
            Log Out
          </MenuItem>

        </Menu>

       


        <Menu
          anchorEl={secondMenuAnchorEl}
          open={Boolean(secondMenuAnchorEl)}
          onClose={handleSecondMenuClose}
        >
          <MenuItem 
            style={{ 
              display: "flex", 
              justifyContent: "space-between", 
              alignItems: "center", 
              padding: "12px 16px", 
              gap: "8px" 
            }}
          >
              <Box display="flex" alignItems="center" gap="8px">
              <GiUpgrade style={{ color: "#fff" }} /> {/* Attractive Icon */}
            <span style={{ fontWeight: "bold", fontSize: "16px" }}>BaapGPT Plus</span>
            </Box>
            <Button 
              variant="contained" 
              color="primary" 
              size="small" 
              onClick={() => navigate("/upgradeyourplan")}
              style={{ textTransform: "capitalize", borderRadius: "8px", padding: "6px 12px" }}
            >
              Upgrade
            </Button>
          </MenuItem>

          <MenuItem 
            style={{ 
              display: "flex", 
              justifyContent: "space-between", 
              alignItems: "center", 
              padding: "12px 16px", 
              gap: "8px" 
            }}
          >
              <Box display="flex" alignItems="center" gap="8px">
              <BsChatSquareDots style={{ color: "#fff" }} /> {/* Attractive Icon */}
              </Box>
            <span style={{ fontWeight: "bold", fontSize: "16px" }}>Temporary Chat</span>
            <Box display="flex" alignItems="center" gap="4px">
              <Switch 
                checked={isChatEnabled} 
                onChange={toggleChat} 
                color="primary"
                inputProps={{ "aria-label": "Temporary Chat Toggle" }}
              />
              <span style={{ fontSize: "14px", color: isChatEnabled ? "#1976d2" : "#666" }}>
                {isChatEnabled ? "On" : "Off"}
              </span>
            </Box>
          </MenuItem>
        </Menu>



        <IconButton color="inherit" onClick={handleShare}>
          <FaShareAlt />
        </IconButton>
        
      </Toolbar>
      
    </AppBar>
  </>
    
  );
};

export default DashNavbar;
