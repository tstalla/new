import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import {
  Modal,
  Box,
  Button,
  CircularProgress,
  TextField,
  Typography,
  IconButton,
  Avatar,
} from "@mui/material";
import {
  Edit as EditIcon,
  PhotoCamera as PhotoCameraIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import userprofile from "../Assets/Image/userprofile.png";

const ProfileModal = ({ show, onClose,onImageUpload }) => {
 
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [profilePictureBlobURL, setProfilePictureBlobURL] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState({ name: "", email: "" });
  const [userId]=useState();

  useEffect(() => {
    let temp = localStorage.getItem("email");
    const userId = localStorage.getItem("user_id");

    const fetchData = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/UserProfile/${userId}`, {
          email: temp,
        });
        setUserData(response.data.user_data);
        onImageUpload(); // Notify Topbar to reload the profile update
      } catch (error) {
        console.error("Error fetching data:", error.message);
        setError(
          "An error occurred while fetching user data. Please try again later."
        );
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [show]);

  useEffect(() => {
    if (userData) {
      setEditedData({ name: userData.name, email: userData.email });
    }
  }, [userData]);

  useEffect(() => {
    if (userData && !userData.profile_picture) {
      const fetchProfilePicture = async () => {
        try {
          const response = await axios.get(
            `http://127.0.0.1:8000/get-profile-picture/${userData.id}/`,
            {
              responseType: "blob",
            }
          );
          const blobURL = URL.createObjectURL(response.data);
          setProfilePictureBlobURL(blobURL);
        } catch (error) {
          console.error("Error fetching profile picture:", error.message);
        }
      };
      fetchProfilePicture();
    }
  }, [userData]);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedImage(file);
  };

  const handleUploadSubmit = async () => {
    if (!selectedImage) {
      return;
    }

    const formData = new FormData();
    formData.append("profile_picture", selectedImage);

    const user_id = localStorage.getItem("user_id");
    formData.append("user_id", user_id);

    setIsUploading(true);

    try {
      const response = await axios.post(
        "http://127.0.0.1:8000/upload-profile-picture/",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
          responseType: "arraybuffer",
        }
      );
      setUserData({
        ...userData,
        profile_picture: response.data.profile_picture_url,
      });
      const blob = new Blob([response.data], { type: "image/jpeg" });
      const blobURL = URL.createObjectURL(blob);
      setProfilePictureBlobURL(blobURL);
      setSelectedImage(null);
      setIsUploading(false);
      onImageUpload(); // Notify Topbar to reload the profile picture
      onClose();
      Swal.fire({
        icon: "success",
        title: "Profile Picture Uploaded",
        text: "Your profile picture has been updated successfully!",
        
      })
    } catch (error) {
      console.error("Error uploading profile picture:", error.message);
      Swal.fire({
        icon: "error",
        title: "Upload Failed",
        text: "An error occurred while uploading your profile picture. Please try again.",
      });
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleSaveChanges = async () => {
    const userId = localStorage.getItem("user_id");
  
    try {
      const response = await axios.put(
        `http://127.0.0.1:8000/UserProfile/${userId}/`, // Ensure correct URL format
        {
          name: editedData.name,
          email: editedData.email,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
  
      if (response.data.message === 'User profile updated successfully.') {
        setUserData(response.data.user_data);
        setIsEditing(false);
        onClose();
        Swal.fire({
          icon: "success",
          title: "Changes Saved",
          text: "Your profile information has been updated successfully!",
        })
      } else {
        throw new Error('Failed to update profile');
      }
    } catch (error) {
      console.error("Error saving changes:", error.message);
      Swal.fire({
        icon: "error",
        title: "Save Failed",
        text: "An error occurred while saving your profile changes. Please try again.",
      });
    }
  };
  
  return (
    <Modal
      open={show}
       onClose={onClose}
      aria-labelledby="profile-modal-title"
      aria-describedby="profile-modal-description"
    >
      <Box
        sx={{
          width: "100%",
          maxWidth: 600,
          bgcolor: "background.paper",
          borderRadius: 2,
          p: 3,
          boxShadow: 3,
          mx: "auto",
          mt: 5,
          position: "relative",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <IconButton
          onClick={onClose}
          sx={{
            position: "absolute",
            top: 10,
            right: 10,
          }}
        >
          <CloseIcon />
        </IconButton>
        <Typography id="profile-modal-title" variant="h5" gutterBottom>
          User Profile
        </Typography>
        {loading ? (
          <CircularProgress />
        ) : error ? (
          <Typography color="error">{error}</Typography>
        ) : userData ? (
          <>
            <Box display="flex" flexDirection="column" alignItems="center">
              <Avatar
                src={
                  profilePictureBlobURL || userData.profile_picture || userprofile
                }
                sx={{ width: 120, height: 120, mb: 2 }}
              />
              <Box display="flex" alignItems="center" justifyContent="space-between" width="100%">
                {isEditing ? (
                  <TextField
                    name="name"
                    label="Name"
                    value={editedData.name}
                    onChange={handleInputChange}
                    fullWidth
                    margin="normal"
                  />
                ) : (
                  <Typography variant="h6" sx={{ flexGrow: 1 }}>
                    {userData.name}
                  </Typography>
                )}
                <IconButton onClick={() => setIsEditing(!isEditing)} color="primary" sx={{ ml: 2 }}>
                  <EditIcon />
                </IconButton>
              </Box >
              {isEditing && (
                <Box width="100%" mt={2} display="flex" justifyContent="flex-end">
                  <Button variant="contained" color="primary" onClick={handleSaveChanges} sx={{ mr: 1 }}>
                    Save
                  </Button>
                  <Button variant="outlined" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                </Box >
              )}
              <Box width="100%" mt={2} textAlign="center">
                <label htmlFor="profilePicture">
                  <Button
                    variant="contained"
                    color="secondary"
                    component="span"
                    startIcon={<PhotoCameraIcon />}
                  >
                    Change Picture
                  </Button>
                </label>
                <input
                  id="profilePicture"
                  type="file"
                  accept="image/*"
                  className="d-none"
                  onChange={handleFileChange}
                />
              </Box>
              {selectedImage && (
                <Box mt={2} display="flex" justifyContent="center">
                  <Typography variant="body2">Selected Image: {selectedImage.name}</Typography>
                </Box>
              )}
              {selectedImage && (
                <Box mt={2} display="flex" justifyContent="center">
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={handleUploadSubmit}
                    disabled={isUploading}
                  >
                    {isUploading ? <CircularProgress size={24} /> : "Upload"}
                  </Button>
                </Box>
              )}
            </Box>
          </>
        ) : null}
      </Box>
    </Modal>
  );
};

export default ProfileModal;