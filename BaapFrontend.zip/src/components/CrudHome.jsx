import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import DashNavbar from "./DashNavbar";

function CrudHome() {
    const [data, setData] = useState([]);
    const [message, setMessage] = useState(null);

    useEffect(() => {
        axios
            .get("http://127.0.0.1:8000/users/")
            .then((res) => setData(res.data))
            .catch((err) => console.log(err));
    }, []);

    const handleDelete = (id) => {
        axios
            .delete(`http://127.0.0.1:8000/users/delete/${id}`)
            .then((res) => {
                // Filter out the deleted item from the data array
                const updatedData = data.filter((user) => user.id !== id);
                setData(updatedData);
                setMessage("User deleted successfully.");

                 // Clear the message after 3000 milliseconds (3 seconds)
            setTimeout(() => {
                setMessage(null);
            }, 900);
            })
            .catch((err) => {
                console.log(err);
                setMessage("Error deleting user.");

                // Clear the error message after 3000 milliseconds (3 seconds)
            setTimeout(() => {
                setMessage(null);
            }, 1000);
            });
    };

    return (
        <>
            <DashNavbar />
            <div className="auth-inner d-flex justify-content-center align-items-start mt-3" style={{ width: "70vw" }}>
                <div className="w-100 bg-white rounded p-3 ms-5 align-items-center">
                    <h2>User List</h2>
                    {message && (
                        <div className={`alert ${message.includes("Error") ? "alert-danger" : "alert-success"}`}>
                            {message}
                        </div>
                    )}
                    <div className="d-flex justify-content-end">
                        <Link to="/create" className="btn btn-success">
                            Create +
                        </Link>
                    </div>
                    <table className="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((user, index) => (
                                <tr key={index}>
                                    <td>{user.id}</td>
                                    <td>{user.name}</td>
                                    <td>{user.email}</td>
                                    <td>
                                        <Link to={`/read/${user.id}`} className="btn btn-sm btn-info">
                                            Read
                                        </Link>
                                        <Link to={`/edit/${user.id}`} className="btn btn-sm btn-primary mx-2">
                                            Edit
                                        </Link>
                                        <button
                                            onClick={() => handleDelete(user.id)}
                                            className="btn btn-sm btn-danger"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    );
}

export default CrudHome;
