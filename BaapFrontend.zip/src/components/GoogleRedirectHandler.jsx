import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";


function GoogleRedirectHandler() {
  const location = useLocation();
  const navigate = useNavigate(); // Used for redirecting
  const [error, setError] = useState(null); // State for any potential errors
  const [loading, setLoading] = useState(true); // Loading state until user info is fetched

  useEffect(() => {
    // Parse the URL fragment to extract the access token
    const hash = location.hash.substring(1); // Remove the '#'
    const params = new URLSearchParams(hash);
    const accessToken = params.get("access_token");

    if (accessToken) {
      console.log("Access Token:", accessToken);
      // Use the access token to make authenticated requests
      fetch("https://www.googleapis.com/oauth2/v1/userinfo?alt=json", {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Failed to fetch user info");
          }
          return response.json();
        })
        .then((userInfo) => {
          console.log("User Info:", userInfo);
          // Here you can store the user info in state or context and then redirect
          // Redirect to a page after successfully fetching the user info
          setLoading(false);
          navigate("/dashboard"); // Redirect to the dashboard or your desired page
        })
        .catch((error) => {
          console.error("Error fetching user info:", error);
          setError("Failed to fetch user info.");
          setLoading(false);
        });
    } else {
      setError("No access token found in URL.");
      setLoading(false);
    }
  }, [location, navigate]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return <div>Redirecting...</div>;
}

export default GoogleRedirectHandler;
