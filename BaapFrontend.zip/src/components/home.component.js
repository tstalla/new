import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
 
const WelcomePage = () => {
  const canvasRef = useRef(null);
  const [typedText, setTypedText] = useState('');
  const fullText = 'Welcome to BaapGPT';
  const typingSpeed = 100; // Speed in ms per character
  const navigate= useNavigate();
 
  useEffect(() => {
    // Typewriter Effect Logic
    let index = 0;
    const interval = setInterval(() => {
      if (index < fullText.length) {
        setTypedText((prev) => fullText.substring(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
      }
    }, typingSpeed);
 
    return () => clearInterval(interval);
  }, []);
 
  useEffect(() => {
    // Canvas Animation Logic
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationFrameId;
 
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
 
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
 
    const stars = Array.from({ length: 200 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: Math.random() * 1.5,
      vx: Math.floor(Math.random() * 50) - 25,
      vy: Math.floor(Math.random() * 50) - 25,
    }));
 
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.globalCompositeOperation = 'lighter';
 
      stars.forEach((star) => {
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, 2 * Math.PI);
        ctx.fill();
 
        star.x += star.vx / 30;
        star.y += star.vy / 30;
 
        if (star.x < 0 || star.x > canvas.width) star.vx = -star.vx;
        if (star.y < 0 || star.y > canvas.height) star.vy = -star.vy;
      });
    };
 
    const animate = () => {
      draw();
      animationFrameId = window.requestAnimationFrame(animate);
    };
    animate();
 
    return () => {
      window.cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);
  const handleStart = () => {
    navigate("/sign-up");
  }
 
  const circleVariants = {
    hidden: { pathLength: 0, rotate: 0 },
    visible: {
      pathLength: 1,
      rotate: 360,
      transition: {
        pathLength: { duration: 2, ease: "easeInOut" },
        rotate: { duration: 4, ease: "linear", repeat: Infinity }
      }
    }
  };
 
  const pathVariants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: {
      pathLength: 1,
      opacity: 1,
      transition: {
        pathLength: { duration: 2, ease: "easeInOut" },
        opacity: { duration: 1, ease: "easeInOut" }
      }
    }
  };
 
  return (
    <Container>
      <Canvas ref={canvasRef} />
      <Content>
        <LogoContainer
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1, type: 'spring', stiffness: 260, damping: 20 }}
        >
          <Logo viewBox="0 0 200 200">
            <defs>
              <filter id="glow">
                <feGaussianBlur stdDeviation="3.5" result="coloredBlur"/>
                <feMerge>
                  <feMergeNode in="coloredBlur"/>
                  <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
              <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FFD700" />
                <stop offset="100%" stopColor="#FFA500" />
              </linearGradient>
            </defs>
            <motion.circle
              cx="100"
              cy="100"
              r="90"
              stroke="url(#logoGradient)"
              strokeWidth="12"
              fill="none"
              filter="url(#glow)"
              variants={circleVariants}
              initial="hidden"
              animate="visible"
            />
            <motion.path
              d="M60 70 V130 H100 C120 130 130 115 130 100 S120 70 100 70 H60"
              fill="none"
              stroke="url(#logoGradient)"
              strokeWidth="12"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#glow)"
              variants={pathVariants}
              initial="hidden"
              animate="visible"
            />
            <motion.path
              d="M140 70 L120 130 M130 100 H110"
              fill="none"
              stroke="url(#logoGradient)"
              strokeWidth="12"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#glow)"
              variants={pathVariants}
              initial="hidden"
              animate="visible"
            />
          </Logo>
        </LogoContainer>
        <Title
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          {typedText}
          <Cursor>|</Cursor>
        </Title>
        <Subtitle
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          The next generation AI assistant
        </Subtitle>
        <Button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleStart}
        >
          Get Started
        </Button>
      </Content>
    </Container>
  );
};
 
// Styled Components
 
const Container = styled.div`
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(to bottom right, #BA2C76, #9779B6);
  overflow: hidden;
  position: fixed;
  top: 0;
  left: 0;
`;
 
const Canvas = styled.canvas`
  position: absolute;
  top: 0;
  left: 0;
`;
 
const Content = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 1;
  padding: 1rem;
  width: 100%;
  height: 100%;
  max-width: 1200px;
  max-height: 100vh;
  margin: 0 auto;
  overflow: hidden;
`;
 
const LogoContainer = styled(motion.div)`
  width: min(30vh, 200px);
  height: min(30vh, 200px);
  margin-bottom: 2vh;
`;
 
const Logo = styled.svg`
  width: 100%;
  height: 100%;
`;
 
const Title = styled(motion.h1)`
  font-size: clamp(1.5rem, 4vh, 3rem);
  color: white;
  margin-bottom: 1vh;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
`;
 
const Cursor = styled.span`
  display: inline-block;
  margin-left: 4px;
  animation: blink 1s step-start infinite;
 
  @keyframes blink {
    50% {
      opacity: 1;
    }
  }
`;
 
const Subtitle = styled(motion.p)`
  font-size: clamp(1rem, 2.5vh, 1.5rem);
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 2vh;
  text-align: center;
  max-width: 80%;
`;
 
const Button = styled(motion.button)`
  padding: clamp(0.5rem, 1.5vh, 0.75rem) clamp(1.25rem, 3vh, 2rem);
  font-size: clamp(0.9rem, 2vh, 1.2rem);
  color: #8b5cf6;
  background-color: white;
  border: none;
  border-radius: 9999px;
  cursor: pointer;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: background-color 0.3s ease, color 0.3s ease;
 
  &:hover {
    background-color: #f0f0f0;
  }
 
  @media (max-width: 480px) {
    width: 80%;
    max-width: 300px;
  }
`;
 
export default WelcomePage;