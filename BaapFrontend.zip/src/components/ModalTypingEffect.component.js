import React, { useState, useEffect } from "react";
import ClipboardJS from 'clipboard';

const ModalTypingEffect = ({ message, isBot, typingSpeed }) => {
    const [visibleChars, setVisibleChars] = useState(0);
    const [isCopied, setIsCopied] = useState(false);
  
    useEffect(() => {
      const interval = setInterval(() => {
        setVisibleChars((prevVisibleChars) => {
          const nextVisibleChars = prevVisibleChars + 1;
          if (nextVisibleChars > message.length) {
            clearInterval(interval);
          }
          return nextVisibleChars;
        });
      }, typingSpeed || 20);
  
      return () => clearInterval(interval);
  
    }, [message, typingSpeed]);
  
    // const formattedMessage = DOMPurify.sanitize(message.replace(/\*\*(.*?)\*\*/g, (_, match) => `<strong>${match}</strong>`));
    const isCodeResponse = message.includes('```');
  
    useEffect(() => {
      // Initialize clipboard.js for the copy button
      if (isBot && isCodeResponse) {
        const clipboard = new ClipboardJS('.copy-button', {
          text: function () {
            return message; // Set the entire message as the text to be copied
          },
        });
  
        // Handle success event
        clipboard.on('success', () => {
          setIsCopied(true);
  
          // Reset the copied state after a short delay
          setTimeout(() => {
            setIsCopied(false);
          }, 1500);
        });
  
        // Dispose of the clipboard instance when the component unmounts
        return () => clipboard.destroy();
      }
    }, [isBot, isCodeResponse, message]);
  
    return (
      <div className={`message ${isBot ? 'bot' : 'user'}`}>
        <pre className={`message-box ${isBot ? 'bot-message-box' : 'user-message-box'}`}>
          <div className="message-content">
            <div className={`message-text ${isBot ? 'typing-effect' : ''}`}>
              <div className={`message-text ${isCodeResponse ? 'code-block ' : ''}`}>
                {isCodeResponse ? (
                  <div className="code-response-box">
                    <pre>
                      <code>{String(message)}</code>
                    </pre>
                    {/* Copy button */}
                    <button className="copy-button " data-clipboard-text={message}>
                      {isCopied ? 'Code Copied!' : 'Copy'}
                    </button>
                  </div>
                ) : (
                  String(message).substring(0, visibleChars)
                  // isBoldResponse ? <div>{visibleChars}</div> : String(message).substring(0, visibleChars)
                )}
                {isBot && <span className="cursor"></span>}
                {/* {message.substring(0, visibleChars)}
              {isBot && <span className="cursor"></span>} */}
              </div>
            </div>
          </div>
        </pre>
      </div>
    );
  };

export default ModalTypingEffect;
