import React from 'react';
import { Link } from 'react-router-dom';
import { AppBar, Toolbar, Typography, Button, Box,useMediaQuery, IconButton } from '@mui/material';
import TDTLLogo from '../Images/TDTL_Logo.webp'
const Navbar = ({ authenticated, setAuthenticated }) => {
  const handleLogout = async () => {
    try {
      const response = await fetch('http://127.0.0.1:8000/Logout_view/', {
        method: 'POST',
        credentials: 'include',
      });
 
      if (response.ok) {
        console.log('Logout Successful');
        setAuthenticated(false);
        window.location.href = '/';
      } else {
        console.error('Logout Error:', response.statusText);
      }
    } catch (error) {
      console.error('Logout Error:', error.message);
    }
  };
 
  return (
    <AppBar
      position="sticky"
      sx={{
        backgroundColor:'inherit',
        color: 'inherit',
        boxShadow:'none',
      }}
    >
      <Toolbar>
       
 
        {/* Company Logo */}
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          <Link to="/" style={{ textDecoration: 'none', color: 'inherit' }}>
            <img
              src={TDTLLogo}
              alt="The Data Tech Labs Logo"
              style={{ height: '45px', marginBottom: '-12px' }}
            />
          </Link>
        </Typography>
 
        {/* Buttons based on Authentication */}
        <Box sx={{ display: 'flex', gap: 2 }}>
          {authenticated ? (
            <>
              <Button color="inherit" component={Link} to="/dashboard">
                Dashboard
              </Button>
              <Button color="inherit" onClick={handleLogout}>
                Logout
              </Button>
            </>
          ) : (
            <>
              <Button
                color="inherit"
                component={Link}
                to="/sign-up"
                sx={{
                  "&:hover": {
                    color: "blue", // Change text color to blue on hover
                  },
                }}
              >
                Sign Up
              </Button>
              <Button
                color="inherit"
                component={Link}
                to="/sign-in"
                sx={{
                  "&:hover": {
                    color: "blue", // Change text color to blue on hover
                  },
                }}
              >
                Sign In
              </Button>
            </>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
};
 
export default Navbar;