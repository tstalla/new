import React, { useState } from "react";
import { TextField, Button, Box, Typography, Link } from "@mui/material";
import { useNavigate } from "react-router-dom";
import Navbar from './Navbar';  // Import Navbar component
import axios from 'axios';
import Swal from 'sweetalert2';
import innovationImage from '../Images/Innovation-pana 1.svg';
import chatRevolutionImage from '../Images/join-the-chat-revolution-signup.png';
import { GoogleLogin, GoogleOAuthProvider } from "@react-oauth/google";

const Signup = () => {
  const navigate = useNavigate();
  const [, setBackendError] = useState('');
  const [signupError, setSignupError] = useState(""); // For general error messages
  const [errors, setErrors] = useState({}); // For field-specific errors


  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [formErrors, setFormErrors] = useState({
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [showPassword, setShowPassword] = useState(false);

  const validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const isValidPassword = (password) => {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
    return passwordRegex.test(password);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });

    if (name === 'email') {
      setFormErrors({ ...formErrors, email: validateEmail(value) ? '' : 'Invalid email format' });
    } else if (name === 'password') {
      const errorMsg = isValidPassword(value)
        ? ''
        : 'Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.';
      setFormErrors({ ...formErrors, password: errorMsg });
    } else if (name === 'confirmPassword') {
      const confirmError = value !== formData.password ? 'Passwords do not match' : '';
      setFormErrors({ ...formErrors, confirmPassword: confirmError });
    }
  };

  const handleLogin = async (event) => {
    event.preventDefault();
  
    // If there are form validation errors, stop the process
    if (formErrors.email || formErrors.password || formErrors.confirmPassword) {
      return;
    }
  
    const SignupData = {
      name: formData.name,
      email: formData.email,
      password: formData.password,
      confirmPassword: formData.confirmPassword,
    };
  
    try {
      const response = await axios.post(
        "http://127.0.0.1:8000/Signup_view/",
        SignupData,
        { timeout: 100000 }
      );
  
      if (response.status === 201) {
        setSignupError(
          response.data.message || "Signup successful. Please verify your email."
        );
        localStorage.setItem("verificationMessage", "Signup successful. Please verify your email.");
        navigate("/sign-in");
      } else {
        setSignupError("Signup failed. Please try again.");
      }
    } catch (error) {
      if (error.response && error.response.data) {
        const backendErrors = {};
        const { error: generalError } = error.response.data;
  
        if (generalError) {
          setSignupError(generalError);
        } else {
          Object.entries(error.response.data).forEach(([field, message]) => {
            if (formData.hasOwnProperty(field)) {
              backendErrors[field] = message;
            }
          });
        }
        setErrors(backendErrors); // Sets form field errors
      } else {
        setSignupError("An error occurred. Please try again later.");
      }
    }
  };
  

  const toggleShowPassword = () => setShowPassword(!showPassword);

  const handleSuccess = async (credentialResponse) => {
    console.log("Credentials",credentialResponse)
    try {
      const { credential } = credentialResponse;
      if (!credential) {
        console.error("No credential received from Google");
        return;
      }
  
      const response = await axios.post(
        "http://127.0.0.1:8000/google_login/",
        { token: credential },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
  
      if (response.status === 200 || response.status === 201) {
        const userData = response.data.user;
        console.log("User logged in successfully:", userData);
  
        localStorage.setItem("user", JSON.stringify(userData));
        Swal.fire({
          icon: "success",
          title: "Google Login Successful",
          text: `Welcome, ${userData.name}!`,
          timer: 1500,
          showConfirmButton: false,
        });
  
        navigate("/setGooglepassword"); // Navigate to dashboard after login
      } else {
        console.error("Google login failed:", response.data);
        Swal.fire({
          icon: "error",
          title: "Login Failed",
          text: response.data.error_message || "Unknown error occurred.",
        });
      }
    } catch (error) {
      console.error("Error during Google login:", error.response || error);
      Swal.fire({
        icon: "error",
        title: "Login Error",
        text: "An error occurred during login. Please try again.",
      });
    }
  };
  
  const handleError = () => {
    console.error("Google login failed");
    Swal.fire({
      icon: "error",
      title: "Google Login Failed",
      text: "Something went wrong. Please try again.",
    });
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        backgroundColor: "inherit",
        overflow: { xs: "auto", md: "hidden" },
      }}
    >
      {/* Add Navbar here */}
      <Navbar authenticated={false} setAuthenticated={() => {}} /> {/* Set props as needed */}

      {/* Main Content */}
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: "center",
          justifyContent: "space-evenly",
          flexGrow: 1,
          padding: 2,
        }}
      >
        {/* Left Side - Image 1 */}
        <Box
          sx={{
             flex:1,
            display: { xs: "none", sm: "flex" }, // Hide on small screens
            justifyContent: "center",
            alignItems: "center",
            flexDirection:'column',
            textAlign: "center",
            marginBottom: { xs: 3, md: 0 },

          }}
        >
          <img
            src={innovationImage}
            alt="Innovation"
            style={{
              maxHeight: "450px",
              maxWidth: "40%",
              marginBottom: "8px",
            }}
          />
           <img
            src={chatRevolutionImage}
            alt="Chat Revolution"
            style={{
              maxHeight: "120px",
              maxWidth: "30%",
              marginTop:'8px',
            }}
          />
        </Box>

        {/* Right Side - Signup Form */}
        <Box
          component="form"
          onSubmit={handleLogin}
          sx={{
            flex: 1,
            padding: { xs: 2, sm: 6 },
            background: "linear-gradient(to bottom right, #b78dff, #a8d8f8)",
            borderRadius: "15px",
            width: { xs: "80%", sm: "50%", md: "40%" },
            maxWidth: "400px",
            boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
            margin: { xs: "auto", sm: "unset" },
            maxHeight: { xs: "70%", sm: "none" }, // Set maxHeight for small screens
            marginTop: { sm: "-1.5%" },
          }}
        >
          <Typography variant="h6" gutterBottom sx={{ color: "inherit", textAlign: "center" }}>
            Hello! Sign Up Here
          </Typography>

          {/* Form Fields */}
          <TextField
            placeholder="Enter Username"
            name="name"
            variant="outlined"
            fullWidth
            value={formData.name}
            onChange={handleInputChange}
            required
            margin="normal"
            sx={{ backgroundColor: "background.paper", borderRadius: "10px" }}
          />
          <TextField
            placeholder="Email"
            name="email"
            variant="outlined"
            fullWidth
            value={formData.email}
            onChange={handleInputChange}
            error={!!formErrors.email}
            helperText={formErrors.email}
            required
            margin="normal"
            sx={{ backgroundColor: "background.paper", borderRadius: "10px" }}
          />
          <TextField
            placeholder="Password"
            name="password"
            variant="outlined"
            type={showPassword ? "text" : "password"}
            fullWidth
            value={formData.password}
            onChange={handleInputChange}
            error={!!formErrors.password}
            helperText={formErrors.password}
            required
            margin="normal"
            sx={{ backgroundColor: "background.paper", borderRadius: "10px" }}
            InputProps={{
              endAdornment: (
                <Button onClick={toggleShowPassword} sx={{ textTransform: "none" }}>
                  {showPassword ? "Hide" : "Show"}
                </Button>
              ),
            }}
          />
          <TextField
            placeholder="Confirm Password"
            name="confirmPassword"
            variant="outlined"
            type={showPassword ? "text" : "password"}
            fullWidth
            value={formData.confirmPassword}
            onChange={handleInputChange}
            error={!!formErrors.confirmPassword}
            helperText={formErrors.confirmPassword}
            required
            margin="normal"
            sx={{ backgroundColor: "background.paper", borderRadius: "10px" }}
            InputProps={{
              endAdornment: (
                <Button onClick={toggleShowPassword} sx={{ textTransform: "none" }}>
                  {showPassword ? "Hide" : "Show"}
                </Button>
              ),
            }}
          />

          {/* Create Account Button */}
          <Button
            type="submit"
            variant="contained"
            fullWidth
            sx={{
              marginTop: 2,
              backgroundColor: "#002699",
              borderRadius:"10px",
              color:'white',
              "&:hover": {
                backgroundColor: "#5a2274",
              },
            }}
          >
            Create Account
          </Button>

          <GoogleOAuthProvider clientId="950568526445-b3d1a37uck6erdie8asrlnuv23r8j9b1.apps.googleusercontent.com">
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                marginTop: 2, // Spacing above the button
              }}
            >
              <GoogleLogin
                onSuccess={handleSuccess}
                onError={handleError}
                useOneTap={false} // Disable One-Tap Login
                prompt="select_account" // Force Google to ask for account selection
                theme="outline" // Optional: Button theme
                size="medium" // Optional: Button size
              />
            </Box>
          </GoogleOAuthProvider>
          {/* Google Login Button */}
          {/* <Button
            variant="outlined"
            fullWidth
             startIcon={  <FcGoogle  />}
            sx={{
              marginTop: 2,
              borderColor: "#4285F4",
              color: "#4285F4",
              "&:hover": {
                backgroundColor: "#e8f0fe",
              },
            }}
          >
      
          </Button> */}

          {/* Link to Login */}
          <Box sx={{ textAlign: "center", marginTop: 2 }}>
            <Typography variant="body2" sx={{ color: "#000" }}>
              Already have an account?{" "}
              <Link href="/sign-in" sx={{ color: "blue", textDecoration: "none" }}>
                Login
              </Link>
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Signup;
  