import React, { useState, useContext } from "react";
import {
  Box,
  Typography,
  Switch,
  MenuItem,
  IconButton,
  Select,
  FormControl,
  InputLabel,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next"; // Import useTranslation hook
import { ThemeContext } from "./ThemeContext";

const Settings = () => {
  const { t, i18n } = useTranslation(); // Access translation and i18n instance
  const { isDarkMode, toggleTheme } = useContext(ThemeContext);
  const navigate = useNavigate();
  const [language, setLanguage] = useState(i18n.language || "en");

  const handleLanguageChange = (event) => {
    const selectedLanguage = event.target.value;
    setLanguage(selectedLanguage);
    i18n.changeLanguage(selectedLanguage); // Change language in i18n
  };

  const handleExit = () => {
    navigate(-1);
  };

  return (
    <Box
      sx={{
        height: "100vh",
        width: "100vw",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        position: "relative",
        backgroundColor: isDarkMode ? "#333" : "#fff",
        color: isDarkMode ? "#fff" : "#000",
      }}
    >
      {/* Exit Button */}
      <IconButton
        onClick={handleExit}
        sx={{
          position: "absolute",
          top: "20px",
          right: "20px",
          color: isDarkMode ? "#fff" : "#000",
        }}
      >
        <CloseIcon sx={{ fontSize: "32px" }} />
      </IconButton>

      {/* Content */}
      <Box sx={{ textAlign: "center", padding: "20px", width: "80%" }}>
        <Typography variant="h4" gutterBottom>
          {t("Settings")}
        </Typography>

        {/* Theme Toggle */}
        <MenuItem sx={{ justifyContent: "center", mt: 2 }}>
          <Typography variant="body1" sx={{ mr: 2 }}>
            {t("darkMode")}
          </Typography>
          <Switch checked={isDarkMode} onChange={toggleTheme} />
        </MenuItem>
      </Box>
    </Box>
  );
};

export default Settings;
