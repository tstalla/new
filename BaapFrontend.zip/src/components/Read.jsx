import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
// import Sidebar from "./Sidebar";
import DashNavbar from "./DashNavbar";

function ReadUser() {
  const { id } = useParams();
  const [user, setUser] = useState({});

  useEffect(() => {
    axios
      .get(`http://127.0.0.1:8000/users/read/${id}/`)
      .then((res) => {
        console.log(res);
        setUser(res.data); // or setUsert(res.data) depending on the API response structure
      })
      .catch((err) => {
        console.error(err);
        // Handle error
      });
  }, [id]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh" }}>
      <DashNavbar />
      <div style={{ display: "flex", flex: 1 }}>
        {/* <Sidebar /> */}
        <div style={{ flex: 1 }}>
          <div
            className=" mt-5 auth-inner d-flex bg-light justify-content-center align-items-center"
            style={{ width: "40vw", height: "70%" }}
          >
            <div className="w-100 rounded p-3">
              <h2>User Details</h2>
              <div className="p-3 d-flex flex-column align-items-start">
                <h4>ID:{user.id}</h4>
                <h4>Name:{user.name}</h4>
                <h4>Email:{user.email}</h4>
              </div>
              <Link to="/crudHome" className="btn btn-primary me-2">
                Back
              </Link>
              <Link to={`/edit/${user.id}`} className="btn btn-info">
                Edit
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ReadUser;
