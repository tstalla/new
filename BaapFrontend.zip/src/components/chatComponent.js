import React, { useState, useEffect, useRef } from 'react';
import { Box, Button, TextField, Typography, Grid,} from '@mui/material';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import { FaMicrophone } from 'react-icons/fa6';
import { IoSend } from 'react-icons/io5';
import Swal from 'sweetalert2';

const TemporaryChat = () => {
  const [messages1, setMessages1] = useState([]);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [isBotProcessing, setBotProcessing] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [showWelcomeMessage, setShowWelcomeMessage] = useState(true);
  const chatContainerRef = useRef(null);
  const messagesEndRef = useRef(null);
  const [isListening, setIsListening] = useState(false);

  const handleInputChange = (e) => {
    setUserInput(e.target.value);
  };

  const sendMessageToBot = () => {
    if (isBotProcessing || !userInput.trim()) return;

    setBotProcessing(true);
    setMessages1((prevMessages) => [
      ...prevMessages,
      { type: 'user', text: userInput },
      { type: 'bot', text: 'This is a temporary response from the bot.' },
    ]);
    setUserInput('');
    setSelectedImage(null);
    setBotProcessing(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    sendMessageToBot();
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages1]);

  useEffect(() => {
    // Remove welcome message after 3 seconds
    const timer = setTimeout(() => {
      setShowWelcomeMessage(false);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  
  let recognition;
  if (window.SpeechRecognition || window.webkitSpeechRecognition) {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.continuous = false;
  } else {
    alert('Your browser does not support Speech Recognition.');
  }

  const startListening = () => {
    if (!recognition) return;

    setIsListening(true);
    recognition.start();

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setUserInput(transcript);
    };

    recognition.onspeechend = () => {
      setIsListening(false);
      recognition.stop();
    };

    recognition.onerror = (event) => {
      setIsListening(false);
      console.error('Speech recognition error:', event.error);
    };
  };
   // Function to stop listening manually (if needed)
   const stopListening = () => {
    if (recognition && isListening) {
      recognition.stop();
      setIsListening(false);
    }
  };
  const handleErrorMsg = () =>{
    Swal.fire({
              icon: 'error',
              title: 'Cant access on History',
           
            });
  }
 

  return (
    <Box sx={{ display: 'flex', height: '100vh', backgroundColor: 'inherit' }}>
      {/* <Sidebar
        isCollapsed={isSidebarCollapsed}
        onClick={handleErrorMsg}
        sx={{
          position: 'fixed',
          zIndex: 1,
          width: '240px',
          height: '100%',
          boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.5)', // Shadow overlay
          pointerEvents: 'none', // Disables interaction
          opacity: 0.7, // Makes the sidebar look pushed back
          transition: 'opacity 0.3s ease-in-out',
        }}
      /> */}
      <Topbar onSidebarToggle={toggleSidebar} />
      <Box
        ref={chatContainerRef}
        sx={{
          flexGrow: 1,
          backgroundColor: 'primary.main1',
          padding: 2,
          // marginLeft: isSidebarCollapsed ? 0 : '240px',
          transition: 'margin-left 0.3s ease',
          borderRadius: '2%',
          marginTop: '70px',
          display: 'flex',
          flexDirection: 'column',
          height: '87vh',
          overflowY: 'scroll',
          '@media (max-width: 600px)': {
            marginLeft: 0,
          },
        }}
      >
        {/* Welcome Message */}
        {showWelcomeMessage && (
          <Typography
            variant="h5"
            sx={{
              backgroundColor: 'transparent',
              color: 'inherit',
              padding: '10px 20px',
              borderRadius: '5px',
              textAlign: 'center',
              marginBottom: '10px',
              animation: 'fadeOut 5s forwards',
            }}
          >
            Welcome to Temporary Chat!
          </Typography>
        )}

        {/* Chat Content */}
        <Box sx={{ flexGrow: 1, padding: '10px' }}>
          {messages1.map((message, index) => (
            <Box
              key={index}
              sx={{
                display: 'flex',
                flexDirection: message.type === 'user' ? 'row-reverse' : 'row',
                alignItems: 'center',
                marginBottom: '10px',
              }}
            >
              <Box
                sx={{
                  backgroundColor: message.type === 'user' ? 'background.default1' : '#fff',
                  color: message.type === 'user' ? '#000000' : '#333',
                  padding: '10px 15px',
                  borderRadius: '12px',
                  maxWidth: '70%',
                  wordWrap: 'break-word',
                  whiteSpace: 'pre-wrap',
                }}
              >
                {message.text}
              </Box>
            </Box>
          ))}
          <div ref={messagesEndRef} />
        </Box>

        {/* Input Section */}
        <Grid container spacing={1} sx={{ alignItems: 'center', padding: '10px' }}>
          <Grid
            item
            xs={12}
            sm={11}
            sx={{
              display: 'flex',
              alignItems: 'center',
              backgroundColor: 'background.paper',
              borderRadius: '25px',
              padding: '5px 15px',
              boxShadow: '0px 2px 5px rgba(0, 0, 0, 0.1)',
            }}
          >
            <TextField
              fullWidth
              value={userInput}
              onChange={handleInputChange}
              placeholder="Type your text here..."
              variant="outlined"
              InputProps={{
                disableUnderline: true,
                sx: { '& fieldset': { border: 'none' } },
              }}
              sx={{
                backgroundColor: 'transparent',
                paddingLeft: '10px',
                paddingRight: '10px',
              }}
            />
            <FaMicrophone 
                          onClick={isListening ? stopListening : startListening}
                          disabled={isListening} 
                            style={{
                            fontSize: "26px",
                            color: '#9C27B0',
                            backgroundColor: isListening ? "gray" : "transparent",
                            cursor: isListening ? "not-allowed" : "pointer",
                            }}/>
          </Grid>
          <Grid item>
            <Button
              onClick={handleSubmit}
              variant="contained"
              sx={{
                backgroundColor: '#1a4163',
                color: '#fff',
                borderRadius: '50%',
                minWidth: '50px',
                height: '50px',
              }}
            >
              <IoSend />
            </Button>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

export default TemporaryChat;
