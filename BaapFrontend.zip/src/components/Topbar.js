import React, { useState, useEffect } from "react";
import { useNavigate,useLocation } from "react-router-dom";
import {
    Box,
  AppBar,
  Toolbar,
  IconButton,
  Grid,
  Button,
  Avatar,
  Menu,
  MenuItem,
  Typography,
  Switch,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import ShareIcon from "@mui/icons-material/Share";
import { FaUser, FaCog, FaSignOutAlt } from "react-icons/fa";
import AuthService from "./authService";
import ProfileModal from "./ProfileModal";
import axios from "axios";
import bot from "../Images/Baapgpt.png";
import KeyboardDoubleArrowDownIcon from '@mui/icons-material/KeyboardDoubleArrowDown';
import { BsChatSquareDots } from "react-icons/bs";
import { GiUpgrade } from "react-icons/gi";

const Topbar = ({ onSidebarToggle }) => {
  const navigate = useNavigate();
  const location = useLocation(); // Get the current route location
  const [anchorEl, setAnchorEl] = useState(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [userName, setUserName] = useState("");
  const [profilePictureBlobURL, setProfilePictureBlobURL] = useState(null);
  const [userData, setUserData] = useState(null);
  const [secondMenuAnchorEl, setSecondMenuAnchorEl] = useState(null);
  const [isChatEnabled, setIsChatEnabled] = useState(location.pathname === "/chatpage");
  const [reload, setReload] = useState(false); // State to trigger reload


  useEffect(() => {
    const userId = localStorage.getItem("user_id");
    const tempEmail = localStorage.getItem("email");
    const fetchData = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/UserProfile/${userId}`, {
          email: tempEmail,
        });
        setUserData(response.data.user_data);
      } catch (error) {
        console.error("Error fetching user data:", error.message);
      }
    };

    fetchData();
  }, [reload]);

  useEffect(() => {
    if (userData && !userData.profile_picture) {
      const fetchProfilePicture = async () => {
        try {
          const response = await axios.get(
            `http://127.0.0.1:8000/get-profile-picture/${userData.id}/`,
            { responseType: "blob" }
          );
          const blobURL = URL.createObjectURL(response.data);
          setProfilePictureBlobURL(blobURL);
          setReload(false); // Reset reload state after successful fetch
        } catch (error) {
          console.error("Error fetching profile picture:", error.message);
        }
      };

      fetchProfilePicture();
    }
  }, [userData,reload]);
   

  const handleUpdateProfile = (updatedData) => {
    setUserName(updatedData.name);
    setProfilePictureBlobURL(updatedData.profilePictureBlobURL);

    // Update local storage for persistence
    localStorage.setItem("userName", updatedData.name);
    localStorage.setItem("profilePictureBlobURL", updatedData.profilePictureBlobURL);
  };
  const triggerReload = () => {
    setReload(true);
  };


  const handleLogout = async () => {
    try {
      // Call the logout method from AuthService
      await AuthService.logout();
      // Update authentication state directly
      AuthService.isAuthenticated = false;
      localStorage.setItem("authenticated", "false");
      // Redirect to the sign-in page after successful logout
      navigate("/sign-in");
    } catch (error) {
      console.error("Logout Error:", error);
      // Handle logout error if needed
    }
   
   localStorage.removeItem('authenticated');
      // localStorage.removeItem('userName');
      localStorage.removeItem('email');
      localStorage.removeItem('user_id');
  };

  const handleMenuClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleSecondMenuOpen = (event) => {
    setSecondMenuAnchorEl(event.currentTarget);
    
  };

  const handleSecondMenuClose = () => {
    setSecondMenuAnchorEl(null);
  };


  const handleProfileClick = () => {
    setShowProfileModal(true);
    handleMenuClose();
  };
  
  useEffect(() => {
    // Sync the state with the route
    if (location.pathname === "/chatpage") {
      setIsChatEnabled(true); // Keep the button on if we're on the chatpage
    } else if (location.pathname === "/dashboard") {
      setIsChatEnabled(false); // Turn off the button if we're on the dashboard
    }
  }, [location]);

  const toggleChat = () => {
    // Toggle the state of the chat
    setIsChatEnabled((prev) => {
      const newState = !prev;
      // Perform navigation based on the new state
      if (newState) {
        navigate("/chatpage"); // Navigate to chatpage when the button is ON
      } else {
        navigate("/dashboard"); // Navigate to dashboard when the button is OFF
      }
      return newState;
    });
  };

  const handleShare = async (contentToShare) => {
    if (navigator.share) {
      // If Web Share API is supported
      try {
        await navigator.share({
          title: 'Shared from My App',
          text: contentToShare,
          url: window.location.href, // Share the current URL
        });
       
      } catch (error) {
        console.error('Error sharing content:', error);
      }
    } else {
      // Fallback: Copy to clipboard
      navigator.clipboard.writeText(contentToShare).then(
       
      );
    }
  }

  return (
    <>
      <AppBar position="fixed" sx={{ top: 0, left: 0, right: 0, backgroundColor: "background.paper", boxShadow: "none", zIndex: 1200 }}>
        <Toolbar sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center" }}>
            <IconButton edge="start" color="black" aria-label="menu" onClick={onSidebarToggle}>
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" sx={{ fontWeight: "bold", color: "inherit", marginLeft: "10px", display: "flex", alignItems: "center" }}>
              <img src={bot} alt="Bot Icon" style={{ height: "30px", marginRight: "8px", borderRadius: "50%" }} />
              BaapGPT
            </Typography>

            <IconButton color="#1a4163" onClick={handleSecondMenuOpen}>
         <KeyboardDoubleArrowDownIcon />
        </IconButton>
        <Menu
          anchorEl={secondMenuAnchorEl}
          open={Boolean(secondMenuAnchorEl)}
          onClose={handleSecondMenuClose}
        >
          <MenuItem 
            style={{ 
              display: "flex", 
              justifyContent: "space-between", 
              alignItems: "center", 
              padding: "12px 16px", 
              gap: "8px" 
            }}
          >
              <Box display="flex" alignItems="center" gap="8px">
              <GiUpgrade style={{ color: "inherit" }} /> {/* Attractive Icon */}
            <span style={{ fontWeight: "bold", fontSize: "16px" }}>BaapGPT Plus</span>
            </Box>
            <Button 
              variant="contained" 
              color="primary" 
              size="small" 
              onClick={() => navigate("/upgradeyourplan")}
              style={{ textTransform: "capitalize", borderRadius: "8px", padding: "6px 12px",backgroundColor:"#3399ff" }}
            >
              Upgrade
            </Button>
          </MenuItem>

          <MenuItem 
            style={{ 
              display: "flex", 
              justifyContent: "space-between", 
              alignItems: "center", 
              padding: "12px 16px", 
              gap: "8px" 
            }}
          >
              <Box display="flex" alignItems="center" gap="8px">
              <BsChatSquareDots style={{ color: "inherit" }} /> {/* Attractive Icon */}
              </Box>
            <span style={{ fontWeight: "bold", fontSize: "16px" }}>Temporary Chat</span>
            <Box display="flex" alignItems="center" gap="4px">
              <Switch 
                checked={isChatEnabled} 
                onChange={toggleChat} 
                color="primary"
                inputProps={{ "aria-label": "Temporary Chat Toggle" }}
              />
              <span style={{ fontSize: "14px", color: isChatEnabled ? "#1976d2" : "#666" ,}}>
                {isChatEnabled ? "On" : "Off"}
              </span>
            </Box>
          </MenuItem>
        </Menu>

        <Box sx={{ flexGrow: 1 }} />
          </div>
          <Typography
          variant="body1"
          sx={{ marginRight: 0, fontStyle: "italic",color:'inherit' }}
        >
          {userData ? `Welcome, ${userData.name}` : "Welcome, User"}
        </Typography>
          <Grid container alignItems="center" justifyContent="flex-end" sx={{ maxWidth: "300px" }}>
            <Grid item>
            <Button
  onClick={handleShare}
  variant="contained"
  startIcon={<ShareIcon />}
  sx={{
    backgroundColor: "#8EC5FC",
    color: "#fff",
    fontWeight: "bold",
    marginRight: "16px",
    '@media (max-width: 600px)': {
      display: 'none', // Hides the button on mobile screens
    },
  }}
>
  Share
</Button>

            </Grid>
            <Grid item>
                
              <IconButton onClick={handleMenuClick}>
                <Avatar
                  src={profilePictureBlobURL}
                  alt={userData}
                  sx={{ width: 40, height: 40, backgroundColor: "inherit" }}
                >
                  {userData ? userName.charAt(0).toUpperCase() : "U"}
                </Avatar>
              </IconButton>
              
              <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose} sx={{ mt: "45px" }}>
                <MenuItem onClick={handleProfileClick}>
                  <FaUser className="me-2" style={{ marginRight: "8px" }} />
                  Profile
                </MenuItem>
                <MenuItem onClick={() => navigate("/setting")}>
                  <FaCog className="me-2" style={{ marginRight: "8px" }} />
                  Settings
                </MenuItem>
                <MenuItem onClick={handleLogout}>
                  <FaSignOutAlt className="me-2" style={{ marginRight: "8px" }} />
                  Logout
                </MenuItem>
              </Menu>
            </Grid>
          </Grid>
        </Toolbar>
      </AppBar>

      <ProfileModal
        show={showProfileModal}
        onClose={() => setShowProfileModal(false)}
        onUpdateProfile={handleUpdateProfile}
        onImageUpload={triggerReload} // Pass the reload trigger to ProfileModal
      />
    </>
  );
};

export default Topbar;
