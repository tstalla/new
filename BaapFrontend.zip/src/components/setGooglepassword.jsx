import React, { useState, useEffect } from "react";
import { TextField, Button, Box, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import Navbar from "./Navbar";

const SetPassword = () => {
  const [password, setPassword] = useState("");
  const [userId, setUserId] = useState(null); // State to hold user ID
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  // Retrieve userId from localStorage when the component mounts
  useEffect(() => {
    const userData = localStorage.getItem("user"); // Replace with your actual localStorage key
    if (userData) {
      const parsedData = JSON.parse(userData);
      setUserId(parsedData.id); // Set user ID from parsed data
    } else {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: "User data is missing. Please log in again.",
      });
      navigate("/signin"); // Redirect to sign-in page if no user data
    }
  }, [navigate]);

  const handleInputChange = (event) => setPassword(event.target.value);
  const toggleShowPassword = () => setShowPassword(!showPassword);

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!password || password.length < 6) {
      Swal.fire({
        icon: "warning",
        title: "Weak Password",
        text: "Password should be at least 6 characters long.",
        timer: 2000,
        showConfirmButton: false,
      });
      return;
    }

    if (!userId) {
      Swal.fire({
        icon: "error",
        title: "Error",
        text: "User ID is missing. Please log in again.",
      });
      return;
    }

    // Set Password API call
    fetch("http://127.0.0.1:8000/set_password/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ user_id: userId, password }),
    })
      .then((response) => {
        if (response.ok) {
          Swal.fire({
            icon: "success",
            title: "Password Set Successfully!",
            text: "You can now log in with your new password.",
            timer: 1500,
            showConfirmButton: false,
          });
          navigate("/sign-in");
        } else {
          return response.json().then((data) => {
            throw new Error(data?.detail || "Failed to set password");
          });
        }
      })
      .catch((error) => {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: error.message || "Something went wrong. Please try again.",
        });
      });
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        backgroundColor: "inherit",
      }}
    >
      <Navbar authenticated={false} setAuthenticated={() => {}} />
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          flexGrow: 1,
          padding: 2,
        }}
      >
        <Box
          component="form"
          onSubmit={handleSubmit}
          sx={{
            padding: 4,
            background: "linear-gradient(to bottom right, #b78dff, #a8d8f8)",
            borderRadius: "15px",
            width: "100%",
            maxWidth: "400px",
            boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
            margin: "auto",
          }}
        >
          <Typography
            variant="h5"
            gutterBottom
            sx={{ color: "inherit", textAlign: "center", marginBottom: 2 }}
          >
            Set Your Password
          </Typography>

          <TextField
            placeholder="New Password"
            variant="outlined"
            fullWidth
            value={password}
            onChange={handleInputChange}
            margin="normal"
            type={showPassword ? "text" : "password"}
            sx={{
              backgroundColor: "background.paper",
              borderRadius: "10px",
              marginBottom: 2,
            }}
            InputProps={{
              endAdornment: (
                <Button
                  onClick={toggleShowPassword}
                  sx={{
                    textTransform: "none",
                    color: "primary.main",
                    fontWeight: "bold",
                  }}
                >
                  {showPassword ? "Hide" : "Show"}
                </Button>
              ),
            }}
          />

          <Button
            type="submit"
            variant="contained"
            fullWidth
            sx={{
              marginTop: 2,
              backgroundColor: "#6a2c88",
              borderRadius: "10px",
              color: "white",
              "&:hover": {
                backgroundColor: "#5a2274",
              },
            }}
          >
            Set Password
          </Button>
        </Box>
      </Box>
    </Box>
  );
};

export default SetPassword;
