import React, { useState } from "react";
import { Button, TextField, Typography, Box, Alert } from "@mui/material";
import { useNavigate } from "react-router-dom";

const PaymentPage = () => {
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const handleCloseClick = () => {
    navigate(-1); // Goes back to the previous page
  };

  const handlePayment = async () => {
    setLoading(true);
    setError("");

    try {
      // Fetch the Razorpay order ID from the backend
      const response = await fetch(
        "http://127.0.0.1:8000/razorpay/create_order/",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to create Razorpay order");
      }

      const data = await response.json();
      const { order_id, amount, currency } = data;

      // Initialize Razorpay options
      const options = {
        key: "rzp_test_J9OikBpWvaQIgW", // Replace with your Razorpay Key ID
        amount: amount,
        currency: currency,
        name: "BaapGPT Subscription",
        description: "Test Transaction",
        order_id: order_id,
        handler: function (response) {
          alert("Payment Successful!");
          console.log("Payment ID:", response.razorpay_payment_id);
          console.log("Order ID:", response.razorpay_order_id);
          console.log("Signature:", response.razorpay_signature);
        },
        prefill: {
          name: "John Doe",
          email: "john.doe@example.com",
          contact: "8180810028",
        },
        theme: {
          color: "#3399cc",
        },
      };

      const razorpay = new window.Razorpay(options);

      // Open the Razorpay checkout
      razorpay.open();
      setLoading(false);

      razorpay.on("payment.failed", function (response) {
        setError("Payment failed: " + response.error.description);
        console.error("Error:", response.error);
      });
    } catch (error) {
      setLoading(false);
      setError(error.message || "An unexpected error occurred.");
    }
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      sx={{ padding: 4 }}
    >
      <button style={styles.exitButton} onClick={handleCloseClick}>
        &times;
      </button>
      <Typography variant="h4" gutterBottom>
        Razorpay Payment
      </Typography>

      {error && <Alert severity="error">{error}</Alert>}

      <Button
        variant="contained"
        color="primary"
        sx={{ marginTop: 2 }}
        onClick={handlePayment}
        disabled={loading}
      >
        {loading ? "Processing..." : "Pay Now"}
      </Button>
    </Box>
  );
};
const styles = {
  container: {
    position: "relative",
    width: "100vw",
    height: "100vh",
    margin: "0 auto",
    padding: "20px",
    textAlign: "center",
    backgroundColor: "inherit",
    justifyContent: "center",
    color: "inherit",
    fontFamily: "Arial, sans-serif",
    overflowX:'hidden',
    overflowY:'hidden'
  },
  exitButton: {
    position: "absolute",
    top: "10px",
    right: "10px",
    backgroundColor: "inherit",
    border: "none",
    fontSize: "24px",
    color: "inherit",
    cursor: "pointer",
    fontWeight: "bold",
  },
  header: {
    fontSize: "32px",
    marginBottom: "10px",
  },
  subHeader: {
    fontSize: "16px",
    color: "#aaa",
    marginBottom: "30px",
  },
  plansContainer: {
    height: "80vh",
    display: "flex",
    justifyContent: "center",
    flexWrap: "wrap",
    gap: "100px",
  },
  planCard: {
    backgroundColor: "inherit",
    color:'inherit',
    border: "2px solid",
    borderRadius: "10px",
    height: "480px",
    width: "400px",
    padding: "20px",
    textAlign: "left",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    transition: "transform 0.3s ease, box-shadow 0.3s ease",
  },
  planName: {
    fontSize: "20px",
    marginBottom: "5px",
    color: "inherit",
  },
  planPrice: {
    fontSize: "24px",
    margin: "10px 0",
    fontWeight: "bold",
    color: "inherit",
  },
  planDescription: {
    fontSize: "14px",
    marginBottom: "20px",
    color: "inherit",
  },
  featureList: {
    listStyleType: "none",
    padding: 0,
    marginBottom: "20px",
  },
  featureItem: {
    fontSize: "14px",
    marginBottom: "10px",
    display: "flex",
    alignItems: "center",
    color: "inherit",
  },
  button: {
    width: "100%",
    padding: "10px 0",
    border: "none",
    borderRadius: "5px",
    fontSize: "16px",
    transition: "background-color 0.3s ease",
  }
}

export default PaymentPage;
